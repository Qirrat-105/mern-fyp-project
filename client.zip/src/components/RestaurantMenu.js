import React, { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import axios from "axios";

function RestaurantMenu() {
  const { restaurantId } = useParams();
  const [restaurant, setRestaurant] = useState(null);
  const [menu, setMenu] = useState([]);
  const [cart, setCart] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchRestaurantData();
    fetchCart();
  }, [restaurantId]);

  // Fetch restaurant info and menu
  const fetchRestaurantData = async () => {
    try {
      const restaurantRes = await axios.get(
        `http://localhost:5000/api/restaurants/${restaurantId}`
      );
      const menuRes = await axios.get(
        `http://localhost:5000/api/restaurants/${restaurantId}/menu`
      );

      if (restaurantRes.data.success) {
        setRestaurant(restaurantRes.data.restaurant);
      }

      // ✅ Ensure menu is always an array
      if (menuRes.data.success) {
        setMenu(Array.isArray(menuRes.data.menu) ? menuRes.data.menu : []);
      }
    } catch (error) {
      console.error("Error fetching restaurant or menu:", error);
      setMenu([]); // fallback
    } finally {
      setLoading(false);
    }
  };

  // Fetch user cart
  const fetchCart = async () => {
    try {
      const token = localStorage.getItem("token");
      if (!token) return;

      const res = await axios.get("http://localhost:5000/api/cart", {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (res.data.success) {
        setCart(res.data.cart.items || []);
      }
    } catch (error) {
      console.error("Error fetching cart:", error);
    }
  };

  // Add item to cart
  const addToCart = async (productId, dishName) => {
    try {
      const token = localStorage.getItem("token");
      if (!token) {
        alert("Please login to add items to cart");
        return;
      }

      const res = await axios.post(
        "http://localhost:5000/api/cart/add",
        { productId, quantity: 1 },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      if (res.data.success) {
        alert(`✅ ${dishName} added to cart!`);
        fetchCart();
      }
    } catch (error) {
      console.error("Add to cart error:", error);
      alert(error.response?.data?.message || "Failed to add item to cart");
    }
  };

  if (loading)
    return <div className="text-center p-8">Loading menu...</div>;
  if (!restaurant)
    return <div className="text-center p-8">Restaurant not found</div>;

  return (
    <div className="min-h-screen bg-amber-50">
      {/* Header */}
      <header className="bg-amber-900 px-6 py-4 flex items-center justify-between text-white">
        <div className="flex items-center gap-3">
          <img
            src="/logo.png"
            alt="MealMingle Logo"
            className="h-12 w-12 rounded-full"
          />
          <h1 className="text-2xl font-bold">
            MEALMINGLE - {restaurant.name}
          </h1>
        </div>
        <div className="flex flex-wrap justify-center md:justify-end gap-4 text-sm">
  {/* Back to Restaurants */}
  <Link
    to="/"
    className="flex flex-col items-center group"
  >
    <span className="bg-red-600 p-3 rounded-full group-hover:bg-red-700 transition">
      <i className="fas fa-arrow-left text-white"></i>
    </span>
    <span className="mt-1 text-white text-sm">Back</span>
  </Link>

  {/* View Cart */}
  <Link
    to="/cart"
    className="flex flex-col items-center group"
  >
    <span className="bg-green-600 p-3 rounded-full group-hover:bg-green-700 transition">
      <i className="fas fa-shopping-cart text-white"></i>
    </span>
    <span className="mt-1 text-white text-sm">View Cart ({cart.length})</span>
  </Link>

</div>

      </header>

      {/* Restaurant Info */}
      <div className="max-w-6xl mx-auto p-6">
        <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
          <div className="flex items-center gap-6">
            <img
              src={
                restaurant.image.startsWith("http")
                  ? restaurant.image
                  : `http://localhost:5000/images/${restaurant.image.replace(/^\/+/, "")}`
              }
              alt={restaurant.name}
              className="w-24 h-24 rounded-lg object-cover"
            />
            <div>
              <h1 className="text-3xl font-bold text-amber-900">
                {restaurant.name}
              </h1>
              <p className="text-gray-600">{restaurant.description}</p>
              <div className="flex items-center gap-4 mt-2">
                <span className="text-yellow-400">
                  {"⭐".repeat(Math.round(restaurant.rating))}
                </span>
                <span className="text-gray-600">({restaurant.rating})</span>
                <span className="text-gray-600">• {restaurant.cuisine}</span>
                <span className="text-gray-600">• {restaurant.deliveryTime}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Menu Items */}
        {Array.isArray(menu) && menu.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {menu.map((item) => (
              <div
                key={item._id}
                className="bg-white rounded-lg shadow-md p-4"
              >
                <img
                  src={`http://localhost:5000/images/${item.image}`}
                  alt={item.dishName}
                  className="w-full h-48 object-cover rounded-lg mb-4"
                  onError={(e) => {
                    e.target.src =
                      "https://via.placeholder.com/300x200/FF6B6B/FFFFFF?text=Image+Not+Found";
                  }}
                />
                <h3 className="text-xl font-semibold text-amber-800">
                  {item.dishName}
                </h3>
                <p className="text-gray-600 text-sm mb-2">{item.description}</p>
                <div className="flex justify-between items-center">
                  <span className="text-lg font-bold text-red-700">
                    Rs. {item.price}
                  </span>
                  <button
                    onClick={() => addToCart(item._id, item.dishName)}
                    className="px-4 py-2 bg-amber-600 text-white rounded-full hover:bg-amber-700 transition"
                  >
                    Add to Cart
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-center text-gray-500 mt-8">
            No menu items available.
          </p>
        )}
      </div>
    </div>
  );
}

export default RestaurantMenu;
