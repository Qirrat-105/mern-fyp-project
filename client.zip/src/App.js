// src/App.js
import React, { useEffect } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import socket from "./socket";

// Pages
import Home from "./pages/Home";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import ForgotPassword from "./pages/ForgotPassword";
import BookTable from "./pages/BookTable";
import Logout from "./pages/Logout";
import Subscription from "./pages/Subscription";

// Menus
import SpiceLoungeMenu from "./pages/SpiceLoungeMenu";
import UrbanBitesMenu from "./pages/UrbanBitesMenu";
import HungryForkMenu from "./pages/HungryForkMenu";
import PizzaOnlineMenu from "./pages/PizzaOnlineMenu";
import BBQBazaarMenu from "./pages/BBQBazaarMenu";
import KarachiKitchenMenu from "./pages/KarachiKitchenMenu";
import BunKebabiMenu from "./pages/BunKebabiMenu";
import RoyalNihariMenu from "./pages/RoyalNihariMenu";
import ZaiqaJunctionMenu from "./pages/ZaiqaJunctionMenu";
import LahoriCharghaHouseMenu from "./pages/LahoriCharghaHouseMenu";
import TasteYardMenu from "./pages/TasteYardMenu";
import HostCafeMenu from "./pages/hostcafeMenu";

// Cart & Orders
import CartPage from "./pages/CartPage";
import Checkout from "./pages/Checkout";
import ConfirmOrderPage from "./pages/ConfirmOrderPage";

// Admin
import AdminDashboard from "./pages/AdminDashboard";
import AdminLoginPage from "./pages/AdminLoginPage";

// Components
import FloatingChat from "./components/FloatingChat";
import AdminRoute from "./components/AdminRoute";
import RestaurantMenu from "./components/RestaurantMenu";

function App() {
  // 🔔 SOCKET LISTENER (GLOBAL)
  useEffect(() => {
    const userId = localStorage.getItem("userId");

    if (userId) {
      socket.emit("join", userId);
    }

    socket.on("orderStatusUpdated", (data) => {
      alert(`🔔 Your order is now ${data.status}`);
    });

    return () => {
      socket.off("orderStatusUpdated");
    };
  }, []);

  return (
    <Router>
      {/* Global Chatbot */}
      <FloatingChat />

      <Routes>
        {/* Public routes */}
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/book" element={<BookTable />} />
        <Route path="/logout" element={<Logout />} />
        <Route path="/subscription" element={<Subscription />} />

        {/* Restaurant menus */}
        <Route path="/spiceloungemenu" element={<SpiceLoungeMenu />} />
        <Route path="/urban-bites-menu" element={<UrbanBitesMenu />} />
        <Route path="/hungryfork-menu" element={<HungryForkMenu />} />
        <Route path="/pizzaonline-menu" element={<PizzaOnlineMenu />} />
        <Route path="/hostcafe-menu" element={<HostCafeMenu />} />
        <Route path="/bbqbazaar-menu" element={<BBQBazaarMenu />} />
        <Route path="/karachikitchen-menu" element={<KarachiKitchenMenu />} />
        <Route path="/bunkebabi-menu" element={<BunKebabiMenu />} />
        <Route path="/royalnihari-menu" element={<RoyalNihariMenu />} />
        <Route path="/zaiqajunction-menu" element={<ZaiqaJunctionMenu />} />
        <Route path="/lahoricharghahouse-menu" element={<LahoriCharghaHouseMenu />} />
        <Route path="/tasteyard-menu" element={<TasteYardMenu />} />
        <Route
          path="/restaurant/:restaurantId/menu"
          element={<RestaurantMenu />}
        />

        {/* Cart and checkout */}
        <Route path="/cart" element={<CartPage />} />
        <Route path="/checkout" element={<Checkout />} />
        <Route
          path="/order-confirmation/:id"
          element={<ConfirmOrderPage />}
        />

        {/* Admin routes */}
        <Route path="/admin-login" element={<AdminLoginPage />} />
        <Route
          path="/admin"
          element={
            <AdminRoute>
              <AdminDashboard />
            </AdminRoute>
          }
        />
      </Routes>
    </Router>
  );
}

export default App;
