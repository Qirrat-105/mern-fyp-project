import React, { useEffect, useState } from "react";
import axios from "axios";

export default function RevenuePage() {
  const [revenueData, setRevenueData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchRevenue = async () => {
      try {
        const token = localStorage.getItem("token");
        const res = await axios.get("http://localhost:5000/api/admin/revenue", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setRevenueData(res.data);
        setLoading(false);
      } catch (err) {
        console.error(err);
        setLoading(false);
      }
    };

    fetchRevenue();
  }, []);

  if (loading) return <p>Loading revenue data...</p>;

  if (!revenueData) return <p>No revenue data available.</p>;

  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Revenue Overview</h2>
      <div className="space-y-2">
        <p>Total Revenue: <strong>${revenueData.totalRevenue}</strong></p>
        <p>Total Orders: <strong>{revenueData.totalOrders}</strong></p>
        <p>Average Order Value: <strong>${revenueData.averageOrderValue}</strong></p>
      </div>
    </div>
  );
}
