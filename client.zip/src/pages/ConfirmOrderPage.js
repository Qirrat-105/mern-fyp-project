// src/pages/ConfirmOrderPage.jsx
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

function ConfirmOrderPage() {
  const { id } = useParams();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchOrder = async () => {
      try {
        const res = await fetch(`http://localhost:5000/api/order/${id}`); // ✅ Correct route
        const data = await res.json();

        if (data.success && data.order) {
          setOrder(data.order);
        } else {
          setError("Order not found");
        }
      } catch (err) {
        console.error("Error fetching order:", err);
        setError("Failed to load order details");
      } finally {
        setLoading(false);
      }
    };

    fetchOrder();
  }, [id]);

  if (loading) return <p className="text-center mt-10">Loading order details...</p>;
  if (error) return <p className="text-center mt-10 text-red-600">{error}</p>;
  if (!order) return <p className="text-center mt-10 text-gray-600">No order data found.</p>;

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white shadow-lg rounded-lg mt-10">
      <h1 className="text-2xl font-bold mb-4 text-center text-green-600">
        Order Confirmation
      </h1>

      <p><strong>Order ID:</strong> {order._id}</p>
      <p><strong>Status:</strong> {order.status}</p>
      <p><strong>Payment Method:</strong> {order.paymentMethod}</p>
      <p><strong>Address:</strong> {order.clientDetails?.address || "N/A"}</p>
      <p><strong>Total Amount:</strong> Rs. {order.total}</p>


      <h2 className="text-xl font-semibold mt-6 mb-2">Items Ordered:</h2>

      {order?.items?.length > 0 ? (
        <ul className="list-disc pl-6">
          {order.items.map((item, index) => (
            <li key={index}>
              {item.name} — {item.quantity} × Rs.{item.price}
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-gray-600">No items found in this order.</p>
      )}

      <div className="text-center mt-6">
        <p className="text-green-700 font-semibold">
          Thank you for ordering with MealMingle! 🍽️
        </p>
      </div>
    </div>
  );
}

export default ConfirmOrderPage;
