import React, { useEffect, useState } from "react";
import axios from "axios";
import AOS from "aos";
import "aos/dist/aos.css";

const API_URL = process.env.REACT_APP_API_URL || "http://localhost:5000";

function BookTable() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    date: "",
    time: "",
    guests: 1,
    restaurant: "",
    message: "",
  });

  const [showQr, setShowQr] = useState(false);
  const [qrCode, setQrCode] = useState("");
  const [statusMessage, setStatusMessage] = useState("");

  useEffect(() => {
    AOS.init({ duration: 1000, once: true });
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  /* ------------------- Validation ------------------- */
  const validateForm = () => {
    const nameRegex = /^[A-Za-z\s]{3,}$/;
    const phoneRegex = /^\+?\d{10,15}$/;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!formData.name.trim()) return "Name is required";
    if (!nameRegex.test(formData.name.trim()))
      return "Name must contain only letters and be at least 3 characters";

    if (!formData.email.trim()) return "Email is required";
    if (!emailRegex.test(formData.email.trim()))
      return "Please enter a valid email";

    if (!formData.phone.trim()) return "Phone number is required";
    if (!phoneRegex.test(formData.phone.trim()))
      return "Phone number must be 10–15 digits";

    if (!formData.date) return "Please select a date";
    if (!formData.time) return "Please select a time";
    if (!formData.restaurant) return "Please select a restaurant";

    return null;
  };

  /* ------------------- Submit ------------------- */
  const handleSubmit = async (e) => {
    e.preventDefault();
    setShowQr(false);

    const error = validateForm();
    if (error) {
      setStatusMessage(error);
      return;
    }

    try {
      const response = await axios.post(
        `${API_URL}/api/bookTable`,
        formData
      );

      if (response.data.success) {
        setStatusMessage(response.data.message);

        const qrData = `
MealMingle Reservation
Name: ${formData.name}
Email: ${formData.email}
Phone: ${formData.phone}
Date: ${formData.date}
Time: ${formData.time}
Guests: ${formData.guests}
Restaurant: ${formData.restaurant}
Notes: ${formData.message || "None"}
        `;

        setQrCode(
          `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(
            qrData
          )}`
        );

        setShowQr(true);

        setFormData({
          name: "",
          email: "",
          phone: "",
          date: "",
          time: "",
          guests: 1,
          restaurant: "",
          message: "",
        });
      }
    } catch (err) {
      setStatusMessage(
        err.response?.data?.message || "Server error. Try again later."
      );
    }
  };

  return (
    <div className="bg-amber-100 min-h-screen flex items-center justify-center">
      <div
        className="bg-white p-8 rounded-lg shadow-lg w-full max-w-lg"
        data-aos="fade-up"
      >
        {/* Logo */}
        <div className="text-center mb-6">
          <img
            src="/logo.png"
            alt="MealMingle Logo"
            className="h-20 mx-auto mb-2"
          />
          <h1 className="text-2xl font-extrabold text-amber-900">
            MealMingle
          </h1>
        </div>

        <h2 className="text-xl font-bold text-center text-amber-900 mb-4">
          🍽️ Book a Table
        </h2>

        {statusMessage && (
          <p className="text-center text-sm text-red-600 mb-4">
            {statusMessage}
          </p>
        )}

        <form className="space-y-4" onSubmit={handleSubmit}>
          <input
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="Full Name"
            className="w-full px-4 py-2 border rounded"
          />

          <input
            name="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="Email Address"
            className="w-full px-4 py-2 border rounded"
          />

          <input
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            placeholder="Phone Number"
            className="w-full px-4 py-2 border rounded"
          />

          <input
            type="date"
            name="date"
            value={formData.date}
            onChange={handleChange}
            className="w-full px-4 py-2 border rounded"
          />

          <input
            type="time"
            name="time"
            value={formData.time}
            onChange={handleChange}
            className="w-full px-4 py-2 border rounded"
          />

          <select
            name="restaurant"
            value={formData.restaurant}
            onChange={handleChange}
            className="w-full px-4 py-2 border rounded"
          >
            <option value="">Select Restaurant</option>
            <option value="Spice Lounge">Spice Lounge</option>
            <option value="Urban Bites">Urban Bites</option>
            <option value="Karachi Kitchen">Karachi Kitchen</option>
          </select>

          <textarea
            name="message"
            value={formData.message}
            onChange={handleChange}
            placeholder="Special requests (optional)"
            className="w-full px-4 py-2 border rounded"
          />

          <button
            type="submit"
            className="w-full bg-red-600 text-white py-2 rounded hover:bg-red-700 transition"
          >
            Submit Reservation
          </button>
        </form>

        {showQr && (
          <div className="mt-6 text-center">
            <img src={qrCode} alt="Reservation QR" className="mx-auto" />
            <p className="text-sm mt-2 text-gray-600">
              Show this QR code at the restaurant
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

export default BookTable;
