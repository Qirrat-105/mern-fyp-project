import React from "react";

// Seed data for restaurants and menus
const allRestaurants = [
  {
    name: "Spice Lounge",
    cuisine: "Indian",
    menu: [
      { dishName: "Chicken Biryani", price: 450, category: "Main Course" },
      { dishName: "Garlic Naan", price: 80, category: "Bread" },
      { dishName: "Mango Lassi", price: 150, category: "Beverage" },
      { dishName: "Butter Chicken", price: 750, category: "Main Course" },
      { dishName: "Palak Paneer", price: 650, category: "Main Course" },
    ],
  },
  {
    name: "Urban Bites",
    cuisine: "Fast Food",
    menu: [
      { dishName: "Chicken Biryani", price: 450, category: "Main Course" },
      { dishName: "Garlic Naan", price: 80, category: "Bread" },
      { dishName: "Mango Lassi", price: 150, category: "Beverage" },
      { dishName: "Zinger Burger", price: 450, category: "Fast Food" },
      { dishName: "French Fries", price: 200, category: "Fast Food" },
    ],
  },
  {
    name: "Pizza Online",
    cuisine: "Italian",
    menu: [
      { dishName: "Margherita Pizza", price: 800, category: "Pizza" },
      { dishName: "Pasta Alfredo", price: 650, category: "Pasta" },
    ],
  },
  {
    name: "BBQ Bazaar",
    cuisine: "BBQ",
    menu: [
      { dishName: "Chicken Tikka", price: 520, category: "BBQ" },
      { dishName: "Beef Boti", price: 680, category: "BBQ" },
    ],
  },
  {
    name: "Karachi Kitchen",
    cuisine: "Pakistani",
    menu: [
      { dishName: "Chicken Karahi", price: 850, category: "Main Course" },
      { dishName: "Beef Nihari", price: 600, category: "Main Course" },
    ],
  },
  {
    name: "Bun Kebabi",
    cuisine: "Street Food",
    menu: [
      { dishName: "Bun Kebab", price: 120, category: "Street Food" },
      { dishName: "Chaat Papri", price: 180, category: "Street Food" },
    ],
  },
  {
    name: "Host Café",
    cuisine: "Cafe",
    menu: [
      { dishName: "Cappuccino", price: 350, category: "Beverage" },
      { dishName: "Chocolate Cake", price: 450, category: "Dessert" },
    ],
  },
];

export default function MenuPage() {
  // Flatten all menus into a single array for display
  const menus = allRestaurants.flatMap((restaurant) =>
    restaurant.menu.map((item) => ({
      ...item,
      restaurantName: restaurant.name,
      cuisine: restaurant.cuisine,
    }))
  );

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Menus</h2>
      <div className="overflow-x-auto">
        <table className="w-full border border-gray-300 rounded-lg">
          <thead className="bg-gray-100">
            <tr>
              <th className="p-3 border text-left">Dish Name</th>
              <th className="p-3 border text-left">Category</th>
              <th className="p-3 border text-left">Price</th>
              <th className="p-3 border text-left">Restaurant</th>
              <th className="p-3 border text-left">Cuisine</th>
            </tr>
          </thead>
          <tbody>
            {menus.map((menu, index) => (
              <tr key={index} className="hover:bg-gray-50">
                <td className="p-3 border">{menu.dishName}</td>
                <td className="p-3 border">{menu.category}</td>
                <td className="p-3 border">₹{menu.price}</td>
                <td className="p-3 border">{menu.restaurantName}</td>
                <td className="p-3 border">{menu.cuisine}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
