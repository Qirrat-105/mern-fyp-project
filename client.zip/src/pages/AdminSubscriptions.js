import React, { useEffect, useState } from "react";
import axios from "axios";

export default function AdminSubscriptions() {
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const token = localStorage.getItem("token");

  const fetchPendingPlans = async () => {
    try {
      setLoading(true);
      const res = await axios.get(
        "http://localhost:5000/api/subscription/admin/pending",
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (res.data.success) {
        setPlans(res.data.plans);
      }
    } catch (err) {
      console.error(err);
      setError("Failed to load subscription plans");
    }
    setLoading(false);
  };

  const approvePlan = async (id) => {
    if (!window.confirm("Approve this subscription?")) return;

    try {
      await axios.put(
        `http://localhost:5000/api/subscription/admin/approve/${id}`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      alert("Subscription approved");
      fetchPendingPlans();
    } catch (err) {
      alert("Failed to approve subscription");
    }
  };

  const cancelPlan = async (id) => {
    if (!window.confirm("Cancel this subscription?")) return;

    try {
      await axios.put(
        `http://localhost:5000/api/subscription/admin/cancel/${id}`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      alert("Subscription cancelled");
      fetchPendingPlans();
    } catch (err) {
      alert("Failed to cancel subscription");
    }
  };

  useEffect(() => {
    fetchPendingPlans();
  }, []);

  if (loading) return <p>Loading subscriptions...</p>;
  if (error) return <p className="text-red-600">{error}</p>;

  return (
    <div>
      <h2 className="text-2xl font-bold text-amber-900 mb-4">
        Pending Subscriptions
      </h2>

      {plans.length === 0 ? (
        <p>No pending subscriptions.</p>
      ) : (
        <div className="space-y-6">
          {plans.map((plan) => (
            <div
              key={plan._id}
              className="border rounded-lg p-4 shadow bg-amber-50"
            >
              <p className="font-semibold">
                User: {plan.user.name} ({plan.user.email})
              </p>

              <p className="text-sm">
                Week Start:{" "}
                {new Date(plan.weekStart).toLocaleDateString()}
              </p>

              <p className="text-sm font-medium mt-1">
                Status:{" "}
                <span className="text-orange-600 capitalize">
                  {plan.status}
                </span>
              </p>

              <div className="grid md:grid-cols-2 gap-3 mt-3">
                {plan.meals.map((day) => (
                  <div
                    key={day.day}
                    className="bg-white p-3 rounded shadow-sm"
                  >
                    <h4 className="font-semibold">Day {day.day}</h4>
                    <ul className="list-disc pl-5 text-sm">
                      {day.meals.map((meal, idx) => (
                        <li key={idx}>{meal}</li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>

              <div className="flex gap-3 mt-4">
                <button
                  onClick={() => approvePlan(plan._id)}
                  className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
                >
                  Approve
                </button>

                <button
                  onClick={() => cancelPlan(plan._id)}
                  className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700"
                >
                  Cancel
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
