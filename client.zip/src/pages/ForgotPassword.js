// src/pages/ForgotPassword.js
import React, { useState, useEffect } from "react";
import AOS from "aos";
import "aos/dist/aos.css";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";

function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [newPassword, setNewPassword] = useState(""); // Optional: for direct reset
  const navigate = useNavigate();

  useEffect(() => {
    document.title = "Forgot Password - MealMingle";
    AOS.init({ duration: 1000, once: true });
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        "http://localhost:5000/api/auth/forgot-password",
        { email, newPassword }
      );

      if (response.data.success) {
        alert(response.data.message);
        navigate("/login");
      } else {
        alert(response.data.message || "Password reset failed");
      }
    } catch (err) {
      console.error(err);
      alert("Something went wrong. Try again.");
    }
  };

  return (
    <div className="font-sans text-gray-800 bg-amber-100 min-h-screen flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-lg p-8 w-full max-w-lg" data-aos="fade-up">
        <div className="text-center mb-6">
          <img src="logo.png" alt="MealMingle Logo" className="h-20 w-20 mx-auto mb-4" />
          <h1 className="text-4xl font-extrabold text-amber-900">MEALMINGLE</h1>
        </div>

        <h2 className="text-3xl font-bold text-amber-900 text-center">
          Forgot Your Password?
        </h2>
        <p className="text-gray-600 mt-2 text-center">
          Enter your email and we'll update your password.
        </p>

        <form className="space-y-5 mt-4" onSubmit={handleSubmit}>
          <div>
            <label htmlFor="email" className="block text-left font-medium text-gray-700">
              Email Address
            </label>
            <input
              type="email"
              id="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full mt-1 px-4 py-2 border rounded focus:outline-none focus:ring focus:ring-red-400"
              required
            />
          </div>

          <div>
            <label htmlFor="newPassword" className="block text-left font-medium text-gray-700">
              New Password
            </label>
            <input
              type="password"
              id="newPassword"
              placeholder="Enter new password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="w-full mt-1 px-4 py-2 border rounded focus:outline-none focus:ring focus:ring-red-400"
              required
            />
          </div>

          <div>
            <button
              type="submit"
              className="w-full bg-red-600 text-white px-4 py-2 rounded-full hover:bg-red-700 transition"
            >
              Reset Password
            </button>
          </div>
        </form>

        <p className="text-sm text-center text-gray-600 mt-4">
          Remembered your password?{" "}
          <Link to="/login" className="text-red-600 hover:underline">
            Go back to login
          </Link>
        </p>
      </div>
    </div>
  );
}

export default ForgotPassword;