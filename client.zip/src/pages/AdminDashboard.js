import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import OrdersPage from "./OrdersPage";
import UsersPage from "./UsersPage";
import MenuPage from "./MenuPage";
import AdminSubscriptions from "./AdminSubscriptions";
import AdminBookings from "./AdminBookings";

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState("menus");
  const navigate = useNavigate();

  // 🔐 Protect dashboard (no token → admin login)
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      navigate("/admin-login", { replace: true });
    }
  }, [navigate]);

  // 🚪 Logout handler
  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/admin-login", { replace: true });
  };

  const renderTab = () => {
    switch (activeTab) {
      case "menus":
        return <MenuPage />;
      case "orders":
        return <OrdersPage />;
      case "users":
        return <UsersPage />;
      case "subscriptions":
        return <AdminSubscriptions />;
      case "bookings":
        return <AdminBookings />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-amber-50">
      {/* Header */}
      <header className="flex items-center justify-between bg-amber-900 text-white px-8 py-4 shadow-md sticky top-0 z-50">
        <div className="flex items-center space-x-4">
          <img
            src="/logo.png"
            alt="MealMingle Logo"
            className="w-12 h-12 rounded-full border-2 border-white"
          />
          <h1 className="text-2xl font-bold tracking-wide">
            MealMingle Admin Dashboard
          </h1>
        </div>

        <button
          onClick={handleLogout}
          className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded"
        >
          Logout
        </button>
      </header>

      {/* Navigation Tabs */}
      <nav className="flex justify-center mt-6 flex-wrap gap-3">
        <button
          onClick={() => setActiveTab("menus")}
          className={`px-4 py-2 rounded font-medium ${
            activeTab === "menus"
              ? "bg-red-700 text-white"
              : "bg-red-600 text-white hover:bg-red-700"
          }`}
        >
          Restaurants & Menus
        </button>

        <button
          onClick={() => setActiveTab("orders")}
          className={`px-4 py-2 rounded font-medium ${
            activeTab === "orders"
              ? "bg-blue-700 text-white"
              : "bg-blue-600 text-white hover:bg-blue-700"
          }`}
        >
          Orders
        </button>

        <button
          onClick={() => setActiveTab("bookings")}
          className={`px-4 py-2 rounded font-medium ${
            activeTab === "bookings"
              ? "bg-orange-700 text-white"
              : "bg-orange-600 text-white hover:bg-orange-700"
          }`}
        >
          Bookings
        </button>

        <button
          onClick={() => setActiveTab("users")}
          className={`px-4 py-2 rounded font-medium ${
            activeTab === "users"
              ? "bg-green-700 text-white"
              : "bg-green-600 text-white hover:bg-green-700"
          }`}
        >
          Users
        </button>

        <button
          onClick={() => setActiveTab("subscriptions")}
          className={`px-4 py-2 rounded font-medium ${
            activeTab === "subscriptions"
              ? "bg-purple-700 text-white"
              : "bg-purple-600 text-white hover:bg-purple-700"
          }`}
        >
          Subscriptions
        </button>
      </nav>

      {/* Content */}
      <main className="max-w-6xl mx-auto mt-8 bg-white shadow p-6 rounded-lg">
        {renderTab()}
      </main>
    </div>
  );
}
