import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";

function KarachiKitchenMenu() {
  const [cart, setCart] = useState([]);

  // Load saved cart from localStorage on page load
  useEffect(() => {
    const savedCart = JSON.parse(localStorage.getItem("cart")) || [];
    setCart(savedCart);
  }, []);

  // Add dish to cart with image
  const addToCart = (dishName, price, img) => {
    const currentCart = JSON.parse(localStorage.getItem("cart")) || [];
    const updatedCart = [...currentCart, { dishName, price, img }];
    localStorage.setItem("cart", JSON.stringify(updatedCart));
    setCart(updatedCart);
    alert(`${dishName} added to cart!`);
  };

  // Menu dishes
  const dishes = [
    {
      id: 1,
      name: "Chicken Karahi",
      desc: "Traditional spicy chicken cooked in rich tomato gravy.",
      price: 950,
      img: "/chicken-karahi.jpg",
    },
    {
      id: 2,
      name: "Mutton Karahi",
      desc: "Tender mutton cooked with ginger, garlic, and fresh spices.",
      price: 1400,
      img: "/mutton-karahi.jpeg",
    },
    {
      id: 3,
      name: "Paneer Karahi",
      desc: "Soft cottage cheese simmered in spicy tomato curry.",
      price: 850,
      img: "/paneer-karahi.jpg",
    },
    {
      id: 4,
      name: "Tandoori Naan",
      desc: "Freshly baked naan straight from the tandoor.",
      price: 100,
      img: "/naan.jpg",
    },
    {
      id: 5,
      name: "Mint Raita",
      desc: "Cool yogurt with mint, perfect with spicy dishes.",
      price: 120,
      img: "/raita.jpg",
    },
  ];

  return (
    <div className="bg-amber-50 text-gray-800 font-sans min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-amber-900 px-6 py-4 flex items-center justify-between text-white shadow-lg">
        <div className="flex items-center gap-3">
          <img
            src="/logo.png"
            alt="MealMingle Logo"
            className="h-12 w-12 rounded-full"
          />
          <h1 className="text-2xl font-bold tracking-wide">MEALMINGLE</h1>
        </div>
        <Link
          to="/"
          className="bg-red-600 text-white px-4 py-2 rounded-full hover:bg-red-700 transition"
        >
          🏠 Home
        </Link>
      </header>

      {/* Restaurant Info */}
      <section className="text-center py-10 bg-white shadow">
        <h2 className="text-4xl font-bold text-amber-900 mb-2">
          Karachi Kitchen
        </h2>
        <p className="text-lg text-gray-600">
          Authentic Desi Taste Served Hot 🔥
        </p>
      </section>

      {/* Menu Section */}
      <section className="py-10 px-6 max-w-5xl mx-auto flex-1">
        <h3 className="text-3xl font-semibold text-red-700 mb-6 text-center">
          Menu
        </h3>

        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6">
          {dishes.map((dish) => (
            <div
              key={dish.id}
              className="bg-white rounded-lg shadow-md hover:shadow-xl transition p-4 flex flex-col"
            >
              <img
                src={dish.img}
                alt={dish.name}
                className="h-44 w-full object-cover rounded mb-4"
              />
              <h4 className="text-xl font-bold text-amber-800">{dish.name}</h4>
              <p className="text-gray-600 mb-2">{dish.desc}</p>
              <div className="flex justify-between items-center mt-auto">
                <span className="text-red-600 font-semibold">
                  Rs. {dish.price}
                </span>
                <button
                  className="bg-red-600 text-white px-3 py-1 rounded-full hover:bg-red-700 transition"
                  onClick={() => addToCart(dish.name, dish.price, dish.img)}
                >
                  Add to Cart
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Go to Cart */}
        <div className="text-center mt-10">
          <Link
            to="/cart"
            className="bg-red-600 text-white px-6 py-2 rounded-full hover:bg-red-700 transition"
          >
            🛒 Go to Cart ({cart.length})
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-amber-950 text-white py-6 text-center mt-10">
        <p className="text-sm">© 2025 MealMingle. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default KarachiKitchenMenu;
