import React, { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import axios from "axios";

function Checkout() {
  const [cart, setCart] = useState([]);
  const [numPeople, setNumPeople] = useState(1);
  const [splitAmount, setSplitAmount] = useState(0);
  const [clientDetails, setClientDetails] = useState({
    name: "",
    email: "",
    address: "",
    phone: "",
  });

  const navigate = useNavigate();

  // Fetch cart from backend
  useEffect(() => {
    const fetchCart = async () => {
      try {
        const token = localStorage.getItem("token");
        const res = await axios.get("http://localhost:5000/api/cart", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setCart(res.data.cart.items || []);
      } catch (err) {
        console.error("Failed to fetch cart:", err);
      }
    };
    fetchCart();
  }, []);

  // Calculate total
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  // Calculate per-person split
  useEffect(() => {
    if (numPeople > 0) {
      setSplitAmount((total / numPeople).toFixed(2));
    }
  }, [numPeople, total]);

  // Handle input change
  const handleClientChange = (e) => {
    setClientDetails({ ...clientDetails, [e.target.name]: e.target.value });
  };

  // Confirm Order
  const handleConfirmOrder = async () => {
    if (!clientDetails.name || !clientDetails.email || !clientDetails.address || !clientDetails.phone) {
      alert("Please fill in all client details");
      return;
    }

    try {
      const token = localStorage.getItem("token");
      const res = await axios.post(
        "http://localhost:5000/api/order/checkout",
        { clientDetails },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      if (res.data.success) {
        alert(res.data.message);

        // Clear frontend cart
        setCart([]);
        localStorage.removeItem("cart");

        // Redirect to order confirmation page
        navigate(`/order-confirmation/${res.data.order._id}`);
      }
    } catch (err) {
      console.error("Checkout failed:", err);
      alert(err.response?.data?.message || "Checkout failed");
    }
  };

  return (
    <div className="bg-amber-50 min-h-screen font-sans">
      {/* Header */}
      <header className="bg-amber-900 px-6 py-4 flex items-center justify-between text-white">
        <div className="flex items-center gap-3">
          <img src="/logo.png" alt="MealMingle" className="h-12 w-12 rounded-full" />
          <h1 className="text-2xl font-bold">MEALMINGLE</h1>
        </div>
        <Link to="/" className="bg-red-600 px-4 py-2 rounded-full hover:bg-red-700 transition">Home</Link>
      </header>

      {/* Checkout Section */}
      <div className="max-w-4xl mx-auto bg-white shadow-md rounded-lg p-6 mt-10">
        <h2 className="text-3xl font-bold text-amber-900 mb-6 text-center">Checkout</h2>

        {cart.length === 0 ? (
          <p className="text-center text-gray-600">
            Your cart is empty. <Link to="/" className="text-red-600 underline">Go back</Link> to order something!
          </p>
        ) : (
          <>
            {/* Cart Items */}
            <div className="space-y-4 mb-6">
              {cart.map((item, index) => (
                <div key={index} className="flex items-center justify-between border-b pb-3">
                  <div className="flex items-center gap-4">
                    <img src={item.img} alt={item.dishName} className="h-16 w-16 object-cover rounded" />
                    <div>
                      <h3 className="font-semibold text-lg">{item.dishName}</h3>
                      <p className="text-gray-600">Rs. {item.price} x {item.quantity}</p>
                    </div>
                  </div>
                  <span className="text-red-600 font-semibold">Rs. {item.price * item.quantity}</span>
                </div>
              ))}
            </div>

            {/* Bill Summary */}
            <div className="border-t pt-4">
              <div className="flex justify-between text-xl font-semibold mb-4">
                <span>Total</span>
                <span className="text-red-700">Rs. {total}</span>
              </div>

              {/* Split Bill */}
              <div className="bg-amber-100 p-4 rounded-lg mb-6">
                <h4 className="text-lg font-semibold mb-2 text-amber-900">Split the Bill</h4>
                <div className="flex items-center gap-4">
                  <label className="text-gray-700">Number of People:</label>
                  <input
                    type="number"
                    min="1"
                    value={numPeople}
                    onChange={(e) => setNumPeople(Number(e.target.value))}
                    className="border border-gray-300 rounded px-3 py-1 w-20"
                  />
                </div>
                <p className="mt-2 text-gray-700">
                  Each person pays: <span className="font-semibold">Rs. {splitAmount}</span>
                </p>
              </div>

              {/* Client Details */}
              <div className="bg-amber-100 p-4 rounded-lg mb-6">
                <h4 className="text-lg font-semibold mb-2 text-amber-900">Client Details</h4>
                <input
  type="text"
  id="name"
  name="name"
  value={clientDetails.name}
  onChange={handleClientChange}
  placeholder="Full Name"
  className="border border-gray-300 rounded px-3 py-2 w-full"
/>

<input
  type="email"
  id="email"
  name="email"
  value={clientDetails.email}
  onChange={handleClientChange}
  placeholder="Email Address"
  className="border border-gray-300 rounded px-3 py-2 w-full"
/>

<input
  type="text"
  id="phone"
  name="phone"
  value={clientDetails.phone}
  onChange={handleClientChange}
  placeholder="Phone Number"
  className="border border-gray-300 rounded px-3 py-2 w-full"
/>

<input
  type="text"
  id="address"
  name="address"
  value={clientDetails.address}
  onChange={handleClientChange}
  placeholder="Delivery Address"
  className="border border-gray-300 rounded px-3 py-2 w-full"
/>

              </div>

              {/* Confirm Button */}
              <div className="text-center">
                <button
                  onClick={handleConfirmOrder}
                  className="bg-green-600 text-white px-6 py-3 rounded-full text-lg font-semibold hover:bg-green-700 transition"
                >
                  Confirm Order
                </button>
              </div>
            </div>
          </>
        )}
      </div>

      {/* Footer */}
      <footer className="bg-amber-950 text-white py-6 text-center mt-10">
        <p className="text-sm">© 2025 MealMingle. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default Checkout;
