import React, { useState, useEffect } from "react";
import { io } from "socket.io-client";

const socket = io("http://localhost:5000", {
  autoConnect: false,
});

function Subscription() {
  const [mealPlan, setMealPlan] = useState([]);
  const [preferences, setPreferences] = useState(null);
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(false);

  const token = localStorage.getItem("token");
  const userId = localStorage.getItem("userId");

  /* =====================
     SOCKET SETUP
  ===================== */
  useEffect(() => {
    if (!userId) return;

    socket.connect();
    socket.emit("join", userId);

    socket.on("subscriptionNotification", (data) => {
      alert(data.message);
      setStatus(data.status);
      fetchMyLatestPlan();
    });

    return () => {
      socket.off("subscriptionNotification");
      socket.disconnect();
    };
  }, [userId]);

  /* =====================
     FETCH LATEST PLAN
  ===================== */
  const fetchMyLatestPlan = async () => {
    try {
      const res = await fetch(
        "http://localhost:5000/api/subscription/my-latest",
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      const data = await res.json();

      if (data.success) {
        setMealPlan(data.plan.meals);
        setPreferences(data.plan.preferences);
        setStatus(data.plan.status);
      }
    } catch (err) {
      console.error("Fetch subscription error:", err);
    }
  };

  useEffect(() => {
    if (token) fetchMyLatestPlan();
  }, [token]);

  /* =====================
     GENERATE PLAN
  ===================== */
  const generatePlan = async (e) => {
    e.preventDefault();
    setLoading(true);

    const form = e.target;

    try {
      const res = await fetch(
        "http://localhost:5000/api/subscription/generate",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            budget: form.budget.value,
            calories: form.calories.value,
            diet: form.diet.value,
            cuisines: form.cuisines.value,
          }),
        }
      );

      const data = await res.json();

      if (data.success) {
        setMealPlan(data.plan);
        setPreferences(data.preferences);
        setStatus("pending");
        alert("Weekly plan generated. Waiting for admin approval.");
      } else {
        alert(data.message || "Failed to generate plan");
      }
    } catch (error) {
      console.error(error);
      alert("Something went wrong");
    }

    setLoading(false);
  };

  return (
    <div className="bg-amber-50 min-h-screen p-6">
      <header className="bg-amber-900 text-white p-6 text-center rounded-lg shadow mb-8">
        <h1 className="text-3xl font-bold">Smart Meal Subscription</h1>
        <p className="text-lg">Weekly plans made from real menu items 🍽️</p>
      </header>

      {/* STATUS */}
      {status === "pending" && (
        <p className="text-center text-yellow-700 font-semibold mb-6">
          ⏳ Waiting for admin approval
        </p>
      )}

      {status === "cancelled" && (
        <p className="text-center text-red-600 font-semibold mb-6">
          ❌ Subscription cancelled by admin
        </p>
      )}

      {/* GENERATE FORM */}
      {status !== "approved" && (
        <section className="max-w-2xl mx-auto bg-white p-6 rounded-xl shadow">
          <h2 className="text-2xl font-bold text-amber-900 mb-4">
            Set Your Preferences
          </h2>

          <form className="space-y-4" onSubmit={generatePlan}>
            <input
              name="budget"
              type="number"
              placeholder="Daily Budget (PKR)"
              className="w-full p-3 border rounded"
              required
            />

            <input
              name="calories"
              type="number"
              placeholder="Calories per Day"
              className="w-full p-3 border rounded"
              required
            />

            <select name="diet" className="w-full p-3 border rounded" required>
              <option value="">Select Diet</option>
              <option value="halal">Halal</option>
              <option value="keto">Keto</option>
              <option value="low-carb">Low Carb</option>
              <option value="vegan">Vegan</option>
            </select>

            <input
              name="cuisines"
              type="text"
              placeholder="Preferred Cuisines (e.g. Pakistani, BBQ)"
              className="w-full p-3 border rounded"
              required
            />

            <button
              type="submit"
              className="w-full bg-amber-900 text-white p-3 rounded hover:bg-amber-800"
            >
              {loading ? "Generating..." : "Generate Weekly Plan"}
            </button>
          </form>
        </section>
      )}

      {/* APPROVED PLAN */}
      {status === "approved" && (
        <>
          {/* Preferences */}
          <section className="max-w-4xl mx-auto bg-white p-6 rounded-xl shadow mt-6">
            <h2 className="text-xl font-bold text-amber-900 mb-4">
              Your Preferences
            </h2>

            <table className="w-full border">
              <tbody>
                <tr>
                  <td className="border p-2 font-semibold">Budget</td>
                  <td className="border p-2">{preferences?.budget} PKR</td>
                </tr>
                <tr>
                  <td className="border p-2 font-semibold">Calories</td>
                  <td className="border p-2">{preferences?.calories}</td>
                </tr>
                <tr>
                  <td className="border p-2 font-semibold">Diet</td>
                  <td className="border p-2">{preferences?.diet}</td>
                </tr>
                <tr>
                  <td className="border p-2 font-semibold">Cuisines</td>
                  <td className="border p-2">{preferences?.cuisines}</td>
                </tr>
              </tbody>
            </table>
          </section>

          {/* Meal Plan */}
          <section className="max-w-4xl mx-auto mt-6 bg-white p-6 rounded-xl shadow">
            <h2 className="text-2xl font-bold text-amber-900 mb-4">
              Your Weekly Meal Plan
            </h2>

            <div className="space-y-4">
              {mealPlan.map((day) => (
                <div
                  key={day.day}
                  className="border p-4 rounded-lg shadow-sm"
                >
                  <h3 className="font-bold text-lg text-amber-900">
                    Day {day.day}
                  </h3>
                  <ul className="list-disc pl-5 mt-2">
                    {day.meals.map((meal, index) => (
                      <li key={index}>{meal}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </section>
        </>
      )}
    </div>
  );
}

export default Subscription;
