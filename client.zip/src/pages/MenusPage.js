import React, { useEffect, useState } from "react";
import axios from "axios";

export default function MenusPage() {
  const [menus, setMenus] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMenus = async () => {
      try {
        const token = localStorage.getItem("token");
        const res = await axios.get("http://localhost:5000/api/admin/menus", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setMenus(res.data);
        setLoading(false);
      } catch (err) {
        console.error(err);
        setLoading(false);
      }
    };

    fetchMenus();
  }, []);

  if (loading) return <p>Loading menus...</p>;

  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Menus</h2>
      <ul className="space-y-2">
        {menus.map((menu) => (
          <li key={menu._id} className="border p-2 rounded">
            <strong>{menu.name}</strong> - ${menu.price}
          </li>
        ))}
      </ul>
    </div>
  );
}
