import React from "react";

export default function OrdersPage() {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-6 text-amber-900">Orders</h2>
      <p className="mb-4">View and manage customer orders here.</p>
      <table className="min-w-full bg-white shadow rounded-lg">
        <thead className="bg-amber-100">
          <tr>
            <th className="py-2 px-4">Order ID</th>
            <th className="py-2 px-4">Customer</th>
            <th className="py-2 px-4">Status</th>
            <th className="py-2 px-4">Total</th>
            <th className="py-2 px-4">Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td className="border px-4 py-2">12345</td>
            <td className="border px-4 py-2">John Doe</td>
            <td className="border px-4 py-2">Pending</td>
            <td className="border px-4 py-2">$25</td>
            <td className="border px-4 py-2">
              <button className="bg-green-500 text-white px-2 py-1 rounded">Mark Completed</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}
