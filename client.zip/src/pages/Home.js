import React, { useState, useEffect } from "react";
import "aos/dist/aos.css";
import AOS from "aos";
import { Link } from "react-router-dom";
import axios from "axios";

function Home() {
  const [search, setSearch] = useState("");
  const [restaurants, setRestaurants] = useState([]);
  const [loading, setLoading] = useState(true);

  React.useEffect(() => {
    AOS.init({ duration: 1000, once: true });
    fetchRestaurants();
  }, []);

  // Fetch restaurants from backend
  const fetchRestaurants = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/restaurants");
      if (res.data.success) {
        setRestaurants(res.data.restaurants);
      }
    } catch (error) {
      console.error("Error fetching restaurants:", error);
    } finally {
      setLoading(false);
    }
  };

  const filteredRestaurants = restaurants.filter((r) =>
    r.name.toLowerCase().includes(search.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-amber-900 mx-auto"></div>
          <p className="mt-4 text-lg">Loading restaurants...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="font-sans text-gray-800 bg-white relative">
      {/* Header - KEEPING YOUR ORIGINAL HEADER EXACTLY THE SAME */}
      <header className="flex flex-col md:flex-row md:items-center md:justify-between p-6 bg-amber-900 text-white">
        <div className="flex items-center space-x-4 mb-4 md:mb-0">
          <img src="logo.png" alt="MealMingle Logo" className="h-14 w-14 rounded-full" />
          <h1 className="text-3xl font-bold">MEALMINGLE</h1>
        </div>

        {/* Navigation - KEEPING YOUR ORIGINAL NAVIGATION */}
        <div className="flex flex-wrap justify-center md:justify-end gap-4 text-sm">
          <Link to="/" className="flex flex-col items-center group">
            <span className="bg-red-600 p-3 rounded-full group-hover:bg-red-700 transition">
              <i className="fas fa-home text-white"></i>
            </span>
            <span className="mt-1 text-white">Home</span>
          </Link>
          <Link to="/book" className="flex flex-col items-center group">
            <span className="bg-blue-600 p-3 rounded-full group-hover:bg-blue-700 transition">
              <i className="fas fa-calendar-check text-white"></i>
            </span>
            <span className="mt-1 text-white">Book a Table</span>
          </Link>
          <Link to="/subscription" className="flex flex-col items-center group">
            <span className="bg-pink-600 p-3 rounded-full group-hover:bg-pink-700 transition">
              <i className="fas fa-utensils text-white"></i>
            </span>
            <span className="mt-1 text-white">Subscription</span>
          </Link>
          <Link to="/signup" className="flex flex-col items-center group">
            <span className="bg-green-600 p-3 rounded-full group-hover:bg-green-700 transition">
              <i className="fas fa-user-plus text-white"></i>
            </span>
            <span className="mt-1 text-white">Sign Up</span>
          </Link>
          <Link to="/login" className="flex flex-col items-center group">
            <span className="bg-purple-600 p-3 rounded-full group-hover:bg-purple-700 transition">
              <i className="fas fa-sign-in-alt text-white"></i>
            </span>
            <span className="mt-1 text-white">Login</span>
          </Link>
          <Link to="/logout" className="flex flex-col items-center group">
            <span className="bg-gray-600 p-3 rounded-full group-hover:bg-gray-700 transition">
              <i className="fas fa-sign-out-alt text-white"></i>
            </span>
            <span className="mt-1 text-white">Logout</span>
          </Link>
          <Link to="/admin" className="flex flex-col items-center group">
            <span className="bg-green-600 p-3 rounded-full group-hover:bg-green-700 transition">
              <i className="fas fa-user-shield text-white"></i>
            </span>
            <span className="mt-1 text-white">Admin</span>
          </Link>
        </div>
      </header>

      {/* Hero Section - KEEPING YOUR ORIGINAL HERO SECTION */}
      <section
        className="h-screen bg-cover bg-center flex items-center justify-center text-white text-center px-4"
        style={{ backgroundImage: "url('image.jpg')" }}
        data-aos="fade-up"
      >
        <div className="bg-black bg-opacity-60 p-10 rounded-lg max-w-2xl">
          <p className="text-5xl font-bold mb-4">🍽️</p>
          <h2 className="text-5xl font-bold mb-4">Welcome to MealMingle</h2>
          <p className="text-xl mb-6">Serving Your Taste Buds — MealMingle Connects You to the Best Kitchens.</p>
        </div>
      </section>

      {/* Restaurant List Section - USING BACKEND DATA */}
      <section className="py-20 px-6 bg-amber-100 text-center" data-aos="fade-up">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold text-amber-900 mb-6">
            🛒 One Stop, Many Kitchens — Your Food Journey Starts Here
          </h2>

          {/* Search Bar */}
          <div className="mb-10 max-w-xl mx-auto">
            <input
              type="text"
              placeholder="🔍 Search restaurants..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full px-4 py-3 rounded-full border border-gray-300 focus:outline-none focus:ring focus:ring-red-400"
            />
          </div>

          {/* Restaurant Grid - USING REAL DATA FROM BACKEND */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filteredRestaurants.map((rest) => (
              <div key={rest._id} className="bg-white rounded-lg shadow p-6 restaurant-card">
                <img 
                  src={rest.image} 
                  alt={rest.name} 
                  className="h-20 mx-auto mb-4 object-cover" 
                />
                <h3 className="restaurant-name text-xl font-semibold text-amber-900 mb-1">
                  {rest.name}
                </h3>
                <div className="flex justify-center text-yellow-400 mb-3">
                  {"⭐".repeat(Math.round(rest.rating))}{" "}
                  <span className="text-sm text-gray-500 ml-2">({rest.rating})</span>
                </div>
                <p className="text-gray-600 mb-4">{rest.description}</p>

                {/* Dynamic Menu Link */}

                <Link
                  to={`/restaurant/${rest._id}/menu`}
                  className="px-4 py-2 text-white bg-amber-600 rounded-lg hover:bg-amber-700 inline-block"
                >
                  🍽️ View Menu
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Us Section with Background Image - KEEPING YOUR ORIGINAL */}
      <section
        className="relative bg-cover bg-center text-white py-20"
        style={{
          backgroundImage: "url('/about.jpg')",
        }}
      >
        {/* Overlay for better readability */}
        <div className="absolute inset-0 bg-black bg-opacity-50"></div>

        <div className="relative z-10 max-w-4xl mx-auto text-center px-6">
          <h1 className="text-3xl font-bold mb-6">About Us</h1>
          <p className="text-lg leading-relaxed">
            At MealMingle, we believe food brings people together. Our platform
            connects hungry customers with restaurants and vendors, making food
            booking fast, simple, and enjoyable. Whether you're planning a quick
            lunch or a family feast, MealMingle has you covered.
          </p>
        </div>
      </section>

      {/* Footer - KEEPING YOUR ORIGINAL FOOTER */}
      <footer className="bg-amber-950 text-white py-8 px-6 text-center">
        <p className="text-sm mb-2">© 2025 MealMingle. All rights reserved.</p>
        <div className="flex justify-center gap-6 text-lg">
          <a href="https://facebook.com" target="_blank" rel="noopener noreferrer">Facebook</a>
          <a href="https://instagram.com" target="_blank" rel="noopener noreferrer">Instagram</a>
          <a href="https://twitter.com" target="_blank" rel="noopener noreferrer">Twitter</a>
        </div>
      </footer>
    </div>
  );
}

export default Home;