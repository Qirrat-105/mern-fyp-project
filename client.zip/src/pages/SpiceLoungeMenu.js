import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";

function SpiceLoungeMenu() {
  const [cart, setCart] = useState([]);
  const [menuItems, setMenuItems] = useState([]);
  const [loading, setLoading] = useState(true);

  // Fetch cart from backend and menu items
  useEffect(() => {
    fetchCart();
    fetchMenuItems();
  }, []);

  // Fetch cart from backend API
  const fetchCart = async () => {
    try {
      const token = localStorage.getItem("token");
      if (!token) return;

      const res = await axios.get("http://localhost:5000/api/cart", {
        headers: { Authorization: `Bearer ${token}` },
      });
      
      if (res.data.success) {
        setCart(res.data.cart.items || []);
      }
    } catch (error) {
      console.error("Error fetching cart:", error);
    }
  };

  // Fetch menu items from backend
  const fetchMenuItems = async () => {
    try {
      // First, get the Spice Lounge restaurant from backend
      const restaurantRes = await axios.get("http://localhost:5000/api/restaurants/name/Spice Lounge");
      
      if (restaurantRes.data.success) {
        const restaurant = restaurantRes.data.restaurant;
        // Then get the menu for this restaurant
        const menuRes = await axios.get(`http://localhost:5000/api/restaurants/${restaurant._id}/menu`);
        
        if (menuRes.data.success) {
          // ✅ Add full URL to backend images
          const menuWithFullUrls = menuRes.data.menu.map(item => ({
            ...item,
            image: `http://localhost:5000/${item.image}`
          }));
          setMenuItems(menuWithFullUrls);
        }
      }
    } catch (error) {
      console.error("Error fetching menu:", error);
      // ✅ Fallback with PROPER image URLs
      // TEMPORARY TEST - External images
setMenuItems([
  { _id: "1", dishName: "Chicken Biryani", description: "Spicy rice with marinated chicken.", price: 450, image: "https://images.unsplash.com/photo-1563379091339-03246963d96f?w=400" },
  { _id: "2", dishName: "Mutton Karahi", description: "Rich tomato gravy with tender mutton.", price: 3000, image: "https://images.unsplash.com/photo-1594041680534-e8c8cdebd659?w=400" },
  { _id: "3", dishName: "Garlic Naan", description: "Freshly baked with butter and garlic.", price: 80, image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=400" },
  { _id: "4", dishName: "Paneer Butter Masala", description: "Creamy tomato gravy with soft paneer cubes.", price: 650, image: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=400" },
  { _id: "5", dishName: "Seekh Kebab", description: "Juicy minced meat grilled to perfection.", price: 900, image: "https://images.unsplash.com/photo-1603360946369-dc9bb6258143?w=400" },
  { _id: "6", dishName: "Butter Chicken", description: "Creamy and mildly spiced chicken curry.", price: 750, image: "https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=400" },
  { _id: "7", dishName: "Vegetable Pulao", description: "Fragrant rice cooked with mixed vegetables.", price: 400, image: "https://images.unsplash.com/photo-1563245372-f21724e3856d?w=400" },
  { _id: "8", dishName: "Masala Chai", description: "Traditional spiced Indian tea.", price: 150, image: "https://images.unsplash.com/photo-1571934811356-5cc061b6821f?w=400" },
  { _id: "9", dishName: "Gulab Jamun", description: "Sweet fried dumplings soaked in sugar syrup.", price: 200, image: "https://images.unsplash.com/photo-1586448900407-5e34f8a86421?w=400" },
]);
    } finally {
      setLoading(false);
    }
  };

  // Add to cart using BACKEND API
  const addToCart = async (productId, dishName) => {
    try {
      const token = localStorage.getItem("token");
      if (!token) {
        alert("Please login to add items to cart");
        return;
      }

      const res = await axios.post(
        "http://localhost:5000/api/cart/add",
        { productId, quantity: 1 },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      if (res.data.success) {
        alert(`✅ ${dishName} added to cart!`);
        // Update cart state with backend data
        setCart(res.data.cart.items || []);
        // Remove old local storage cart data
        localStorage.removeItem("cart");
      }
    } catch (error) {
      console.error("Add to cart error:", error);
      if (error.response?.data?.message) {
        alert(error.response.data.message);
      } else {
        alert("Failed to add item to cart");
      }
    }
  };

  if (loading) {
    return (
      <div className="bg-amber-50 min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-amber-900 mx-auto"></div>
          <p className="mt-4 text-lg text-gray-600">Loading menu...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-amber-50 text-gray-800 font-sans min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-amber-900 px-6 py-4 flex items-center justify-between text-white shadow-md">
        <div className="flex items-center gap-3">
          <img src="/logo.png" alt="MealMingle Logo" className="h-12 w-12 rounded-full" />
          <h1 className="text-2xl font-bold">MEALMINGLE</h1>
        </div>
        <div className="flex gap-4">
          <Link
            to="/"
            className="bg-red-600 text-white px-4 py-2 rounded-full hover:bg-red-700 transition flex items-center gap-2"
          >
            <i className="fas fa-home"></i>
            <span>Home</span>
          </Link>
          <Link
            to="/cart"
            className="bg-green-600 text-white px-4 py-2 rounded-full hover:bg-green-700 transition flex items-center gap-2"
          >
            <span>🛒 Cart ({cart.length})</span>
          </Link>
        </div>
      </header>

      {/* Restaurant Info */}
      <section className="text-center py-10 bg-white shadow">
        <h2 className="text-4xl font-bold text-amber-900 mb-2">Spice Lounge</h2>
        <p className="text-lg text-gray-600">Authentic Desi & Indian Cuisine</p>
      </section>

      {/* Menu Section */}
      <section className="py-10 px-6 max-w-6xl mx-auto flex-1">
        <h3 className="text-3xl font-semibold text-red-700 mb-6 text-center">Menu</h3>

        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6">
          {menuItems.map((dish) => (
            <div
              key={dish._id}
              className="bg-white rounded-lg shadow-md hover:shadow-xl transition p-4 flex flex-col"
            >
              {/* ✅ FIXED: Direct image URL */}
              <img
                src={dish.image}
                alt={dish.dishName}
                className="h-44 w-full object-cover rounded mb-4"
                onError={(e) => {
                  console.log("Image failed to load:", dish.image);
                  e.target.src = 'https://via.placeholder.com/300x200/FF6B6B/FFFFFF?text=Image+Not+Found';
                }}
                onLoad={() => console.log("Image loaded successfully:", dish.image)}
              />
              <h4 className="text-xl font-bold text-amber-800">{dish.dishName}</h4>
              <p className="text-gray-600 mb-2">{dish.description}</p>
              <div className="flex justify-between items-center mt-auto">
                <span className="text-red-600 font-semibold text-lg">Rs. {dish.price}</span>
                <button
                  className="bg-amber-600 text-white px-4 py-2 rounded-full hover:bg-amber-700 transition"
                  onClick={() => addToCart(dish._id, dish.dishName)}
                >
                  Add to Cart
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Cart Summary */}
        <div className="text-center mt-10 p-4 bg-white rounded-lg shadow">
          <h4 className="text-xl font-semibold text-amber-900 mb-2">
            Cart Summary
          </h4>
          <p className="text-gray-600 mb-4">
            {cart.length} item(s) in cart • Total: Rs.{" "}
            {cart.reduce((total, item) => total + item.price * item.quantity, 0)}
          </p>
          <Link
            to="/cart"
            className="bg-amber-900 text-white px-6 py-3 rounded-full hover:bg-amber-950 transition inline-block"
          >
            🛒 Proceed to Checkout
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-amber-950 text-white py-6 text-center mt-10">
        <p className="text-sm">© 2025 MealMingle. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default SpiceLoungeMenu;