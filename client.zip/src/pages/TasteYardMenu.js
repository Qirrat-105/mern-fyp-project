import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";

function TasteYardMenu() {
  const [cart, setCart] = useState([]);

  // Load saved cart
  useEffect(() => {
    const savedCart = JSON.parse(localStorage.getItem("cart")) || [];
    setCart(savedCart);
  }, []);

  const addToCart = (dishName, price, img) => {
    const currentCart = JSON.parse(localStorage.getItem("cart")) || [];
    currentCart.push({ dishName, price, img });
    localStorage.setItem("cart", JSON.stringify(currentCart));
    setCart(currentCart);
    alert(`${dishName} added to cart!`);
  };

  // ✅ Images from PUBLIC folder
  const dishes = [
    {
      id: 1,
      name: "Crispy Chicken Wrap",
      desc: "Grilled tortilla stuffed with crispy chicken, veggies, and house-made sauce.",
      price: 750,
      img: process.env.PUBLIC_URL + "/crispy-wrap.jpeg",
    },
    {
      id: 2,
      name: "Cheesy Fusion Fries",
      desc: "Golden fries topped with creamy cheese, jalapeños, and tangy fusion spices.",
      price: 450,
      img: process.env.PUBLIC_URL + "/cheesy-fries.jpg",
    },
    {
      id: 3,
      name: "Zinger Fusion Burger",
      desc: "Crispy chicken fillet layered with lettuce, spicy mayo, and melted cheese.",
      price: 850,
      img: process.env.PUBLIC_URL + "/fusion-burger.png",
    },
  ];

  return (
    <div className="bg-amber-50 text-gray-800 font-sans min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-amber-900 px-6 py-4 flex items-center justify-between text-white">
        <div className="flex items-center gap-3">
          <img
            src={process.env.PUBLIC_URL + "/logo.png"}
            alt="MealMingle Logo"
            className="h-12 w-12 rounded-full"
          />
          <h1 className="text-2xl font-bold">MEALMINGLE</h1>
        </div>
        <Link
          to="/"
          className="bg-red-600 text-white px-4 py-2 rounded-full hover:bg-red-700 transition flex items-center gap-2"
        >
          <i className="fas fa-home"></i>
          <span>Home</span>
        </Link>
      </header>

      {/* Restaurant Info */}
      <section className="text-center py-10 bg-white shadow">
        <h2 className="text-4xl font-bold text-amber-900 mb-2">Taste Yard</h2>
        <p className="text-lg text-gray-600">
          Fusion meals & fast food treats — where creativity meets flavor!
        </p>
      </section>

      {/* Menu Section */}
      <section className="py-10 px-6 max-w-5xl mx-auto flex-1">
        <h3 className="text-3xl font-semibold text-red-700 mb-6">Menu</h3>

        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6">
          {dishes.map((dish) => (
            <div
              key={dish.id}
              className="bg-white rounded-lg shadow p-4 flex flex-col"
            >
              <img
                src={dish.img}
                alt={dish.name}
                className="h-44 w-full object-cover rounded mb-4"
              />
              <h4 className="text-xl font-bold text-amber-800">{dish.name}</h4>
              <p className="text-gray-600 mb-2">{dish.desc}</p>
              <div className="flex justify-between items-center mt-auto">
                <span className="text-red-600 font-semibold">
                  Rs. {dish.price}
                </span>
                <button
                  onClick={() => addToCart(dish.name, dish.price, dish.img)}
                  className="bg-red-600 text-white px-3 py-1 rounded-full hover:bg-red-700 transition"
                >
                  Add to Cart
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Go to Cart */}
        <div className="text-center mt-10">
          <Link
            to="/cart"
            className="inline-block bg-amber-800 text-white px-6 py-3 rounded-full text-lg font-semibold hover:bg-amber-900 transition"
          >
            Go to Cart ({cart.length})
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-amber-950 text-white py-6 text-center mt-10">
        <p className="text-sm">© 2025 MealMingle. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default TasteYardMenu;
