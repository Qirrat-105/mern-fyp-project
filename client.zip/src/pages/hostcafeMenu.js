import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";

function HostCafeMenu() {
  const [cart, setCart] = useState([]);

  useEffect(() => {
    const savedCart = JSON.parse(localStorage.getItem("cart")) || [];
    setCart(savedCart);
  }, []);

  // ✅ Include image in cart
  const addToCart = (dishName, price, img) => {
    const updatedCart = [...cart, { dishName, price, img }];
    localStorage.setItem("cart", JSON.stringify(updatedCart));
    setCart(updatedCart);
    alert(`${dishName} added to cart!`);
  };

  const dishes = [
    {
      id: 1,
      name: "Cappuccino",
      desc: "Rich espresso with steamed milk and a creamy foam top.",
      price: 450,
      img: "/cappuccino.jpg",
    },
    {
      id: 2,
      name: "Caramel Latte",
      desc: "Smooth espresso blended with milk and caramel syrup.",
      price: 500,
      img: "/caramel-latte.jpg",
    },
    {
      id: 3,
      name: "Iced Mocha",
      desc: "Cold brew coffee mixed with chocolate and whipped cream.",
      price: 550,
      img: "/iced-mocha.jpg",
    },
    {
      id: 4,
      name: "English Breakfast",
      desc: "Eggs, sausages, baked beans, and toast served with tea.",
      price: 850,
      img: "/english-breakfast.jpg",
    },
    {
      id: 5,
      name: "Cheese Omelette",
      desc: "Fluffy eggs filled with melted cheese and herbs.",
      price: 600,
      img: "/cheese-omelette.jpg",
    },
    {
      id: 6,
      name: "Club Sandwich",
      desc: "Triple-layer sandwich with chicken, lettuce, tomato, and mayo.",
      price: 750,
      img: "/club-sandwich.jpeg",
    },
    {
      id: 7,
      name: "Pancakes with Maple Syrup",
      desc: "Soft, buttery pancakes topped with maple syrup.",
      price: 700,
      img: "/pancakes.jpg",
    },
    {
      id: 8,
      name: "Chocolate Croissant",
      desc: "Freshly baked croissant filled with rich chocolate.",
      price: 400,
      img: "/chocolate-croissant.jpg",
    },
    {
      id: 9,
      name: "Blueberry Muffin",
      desc: "Soft muffin bursting with fresh blueberries.",
      price: 350,
      img: "/blueberry-muffin.jpg",
    },
    {
      id: 10,
      name: "Cold Coffee Frappe",
      desc: "Blended coffee with ice cream and whipped cream topping.",
      price: 650,
      img: "/cold-coffee-frappe.jpg",
    },
  ];

  return (
    <div className="bg-amber-50 text-gray-800 font-sans min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-amber-900 px-6 py-4 flex items-center justify-between text-white shadow-md">
        <div className="flex items-center gap-3">
          <img src="/logo.png" alt="MealMingle Logo" className="h-12 w-12 rounded-full" />
          <h1 className="text-2xl font-bold">MEALMINGLE</h1>
        </div>
        <Link
          to="/"
          className="bg-red-600 text-white px-4 py-2 rounded-full hover:bg-red-700 transition flex items-center gap-2"
        >
          <i className="fas fa-home"></i>
          <span>Home</span>
        </Link>
      </header>

      {/* Restaurant Info */}
      <section className="text-center py-10 bg-white shadow">
        <h2 className="text-4xl font-bold text-amber-900 mb-2">Host Café</h2>
        <p className="text-lg text-gray-600">
          Cozy ambiance, freshly brewed coffee, and comfort food served with love.
        </p>
      </section>

      {/* Menu Section */}
      <section className="py-10 px-6 max-w-6xl mx-auto flex-1">
        <h3 className="text-3xl font-semibold text-red-700 mb-6">Menu</h3>

        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6">
          {dishes.map((dish) => (
            <div
              key={dish.id}
              className="bg-white rounded-lg shadow-md hover:shadow-xl transition p-4 flex flex-col"
            >
              <img
                src={dish.img}
                alt={dish.name}
                className="h-44 w-full object-cover rounded mb-4"
              />
              <h4 className="text-xl font-bold text-amber-800">{dish.name}</h4>
              <p className="text-gray-600 mb-2">{dish.desc}</p>
              <div className="flex justify-between items-center mt-auto">
                <span className="text-red-600 font-semibold text-lg">
                  Rs. {dish.price}
                </span>
                <button
                  className="bg-red-600 text-white px-3 py-1 rounded-full hover:bg-red-700 transition"
                  onClick={() => addToCart(dish.name, dish.price, dish.img)}
                >
                  Add
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Go to Cart */}
        <div className="text-center mt-10">
          <Link
            to="/cart"
            className="bg-red-600 text-white px-6 py-2 rounded-full hover:bg-red-700 transition"
          >
            🛒 Go to Cart ({cart.length})
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-amber-950 text-white py-6 text-center mt-10">
        <p className="text-sm">© 2025 MealMingle. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default HostCafeMenu;
