// src/pages/Signup.js
import axios from "axios";
import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import AOS from "aos";
import "aos/dist/aos.css";

function Signup() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  const navigate = useNavigate();

  useEffect(() => {
    AOS.init({ duration: 1000, once: true });
  }, []);

  // Client-side form validation
  const validateForm = () => {
    let temp = {};

    const nameRegex = /^[A-Za-z\s]+$/; // Only letters and spaces

    if (!name.trim()) temp.name = "Name is required";
    else if (!nameRegex.test(name.trim())) temp.name = "Name can only contain letters";
    else if (name.trim().length < 3) temp.name = "Name must be at least 3 characters";

    const gmailRegex = /^[a-zA-Z0-9._%+-]+@gmail\.com$/;
    if (!email.trim()) temp.email = "Email is required";
    else if (!gmailRegex.test(email)) temp.email = "Enter a valid email";

    if (!password.trim()) temp.password = "Password is required";
    else if (password.length < 6) temp.password = "Password must be at least 6 characters";

    setErrors(temp);

    return Object.keys(temp).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    setLoading(true);
    try {
      const { data } = await axios.post("http://localhost:5000/api/auth/signup", {
        name,
        email,
        password
      });

      if (data.success) {
        localStorage.setItem("token", data.token);
        alert("Signup successful!");
        navigate("/login");
      } else {
        alert(data.message || "Signup failed");
      }
    } catch (err) {
      const msg = err.response?.data?.message || "Signup failed";
      alert(msg);

      if (err.response?.data?.errors) {
        const backendErrors = {};
        err.response.data.errors.forEach(error => {
          backendErrors[error.param] = error.msg;
        });
        setErrors(backendErrors);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="font-sans text-gray-800 bg-amber-100 min-h-screen flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-lg p-8 w-full max-w-lg" data-aos="fade-up">
        <div className="text-center mb-6">
          <img src="logo.png" alt="MealMingle Logo" className="h-20 w-20 mx-auto mb-4" />
          <h1 className="text-4xl font-extrabold text-amber-900">MEALMINGLE</h1>
        </div>

        <h2 className="text-2xl font-bold text-center text-amber-900 mb-6">Create an Account</h2>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label htmlFor="name" className="block text-left font-medium text-gray-700">Full Name</label>
            <input
              type="text"
              id="name"
              placeholder="Enter your full name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              pattern="[A-Za-z\s]+"
              title="Name can only contain letters"
              className="w-full mt-1 px-4 py-2 border rounded focus:outline-none focus:ring focus:ring-red-400"
            />
            {errors.name && <p className="text-red-600 text-sm mt-1">{errors.name}</p>}
          </div>

          <div>
            <label htmlFor="email" className="block text-left font-medium text-gray-700">Email Address</label>
            <input
              type="email"
              id="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full mt-1 px-4 py-2 border rounded focus:outline-none focus:ring focus:ring-red-400"
            />
            {errors.email && <p className="text-red-600 text-sm mt-1">{errors.email}</p>}
          </div>

          <div>
            <label htmlFor="password" className="block text-left font-medium text-gray-700">Password</label>
            <input
              type="password"
              id="password"
              placeholder="Create a password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full mt-1 px-4 py-2 border rounded focus:outline-none focus:ring focus:ring-red-400"
            />
            {errors.password && <p className="text-red-600 text-sm mt-1">{errors.password}</p>}
          </div>

          <button
            type="submit"
            className={`w-full bg-red-600 text-white px-4 py-2 rounded-full hover:bg-red-700 transition ${loading ? "opacity-50 cursor-not-allowed" : ""}`}
            disabled={loading}
          >
            {loading ? "Signing up..." : "Sign Up"}
          </button>
        </form>

        <p className="text-sm text-center text-gray-600 mt-4">
          Already have an account?{" "}
          <Link to="/login" className="text-red-600 hover:underline">Log in</Link>
        </p>
      </div>
    </div>
  );
}

export default Signup;
