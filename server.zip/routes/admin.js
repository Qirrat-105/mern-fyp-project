import express from "express";
import Order from "../models/Order.js"; // assuming you have an Order model
import authMiddleware from "../middleware/auth.js";

const router = express.Router();

// Only admins
router.get("/revenue", authMiddleware, async (req, res) => {
  if (req.user.role !== "admin") {
    return res.status(403).json({ success: false, message: "Access denied" });
  }

  try {
    const orders = await Order.find(); // or whatever you use for orders

    const totalRevenue = orders.reduce((acc, order) => acc + order.totalAmount, 0);
    const totalOrders = orders.length;
    const averageOrderValue = totalOrders ? totalRevenue / totalOrders : 0;

    res.json({ totalRevenue, totalOrders, averageOrderValue });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

export default router;
