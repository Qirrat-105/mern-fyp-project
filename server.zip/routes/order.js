import express from "express";
import Order from "../models/Order.js";
import Cart from "../models/Cart.js";
import auth from "../middleware/auth.js";

const router = express.Router();

// ✅ POST /api/order/checkout
router.post("/checkout", auth, async (req, res) => {
  try {
    const { clientDetails, paymentMethod } = req.body;
    const cart = await Cart.findOne({ user: req.user.id }).populate("items.product");

    if (!cart || cart.items.length === 0) {
      return res.status(400).json({ success: false, message: "Cart is empty" });
    }

    // 🧮 Calculate total correctly
    const total = cart.items.reduce(
      (sum, item) => sum + item.product.price * item.quantity,
      0
    );

    // ✅ Create order matching your Order.js schema
    const order = new Order({
      user: req.user.id,
      items: cart.items.map((item) => ({
        product: item.product._id,
        name: item.product.name || item.product.dishName,
        quantity: item.quantity,
        price: item.product.price,
      })),
      total, // ✅ matches Order model field
      clientDetails: {
        name: clientDetails?.name || "N/A",
        email: clientDetails?.email || "N/A",
        phone: clientDetails?.phone || "N/A",
        address: clientDetails?.address || "N/A",
      },
      paymentMethod: paymentMethod || "Cash on Delivery",
      status: "Pending",
      createdAt: new Date(),
    });

    await order.save();

    // ✅ Clear the cart after placing the order
    cart.items = [];
    await cart.save();

    res.status(201).json({
      success: true,
      message: "Order placed successfully",
      order,
    });
  } catch (error) {
    console.error("Checkout Error:", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// ✅ GET /api/order/:id
router.get("/:id", async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({ success: false, message: "Order not found" });
    }
    res.status(200).json({ success: true, order });
  } catch (error) {
    console.error("Fetch Order Error:", error);
    res.status(500).json({ success: false, message: "Failed to fetch order" });
  }
});

export default router;
