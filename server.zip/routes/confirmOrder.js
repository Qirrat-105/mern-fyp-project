import express from "express";
import Order from "../models/Order.js"; // ✅ same model that saves in 'orders' collection

const router = express.Router();

// ✅ Create new order
router.post("/", async (req, res) => {
  try {
    const { orderItems, totalAmount, paymentMethod, userId, address } = req.body;

    const newOrder = new Order({
      items: orderItems,           // store inside 'items' field of your model
      total: totalAmount,          // store as total
      paymentMethod,
      user: userId,
      clientDetails: { address },  // optional (you can add name/email later if needed)
      status: "Pending",
      createdAt: new Date(),
    });

    await newOrder.save();

    res.status(201).json({
      success: true,
      message: "Order placed successfully",
      order: newOrder,
    });
  } catch (error) {
    console.error("Order Error:", error);
    res.status(500).json({ success: false, message: "Failed to place order" });
  }
});

// ✅ Get order by ID
router.get("/:id", async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({ success: false, message: "Order not found" });
    }

    res.status(200).json({ success: true, order });
  } catch (error) {
    console.error("Fetch Order Error:", error);
    res.status(500).json({ success: false, message: "Failed to fetch order" });
  }
});

export default router;
