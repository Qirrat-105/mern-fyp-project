import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";

function CartPage() {
  const [cart, setCart] = useState([]);

  // Fetch cart from backend
  useEffect(() => {
    const fetchCart = async () => {
      try {
        const token = localStorage.getItem("token");
        const res = await axios.get("http://localhost:5000/api/cart", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setCart(res.data.cart.items || []);
      } catch (err) {
        console.error("Failed to fetch cart:", err);
      }
    };

    fetchCart();
  }, []);

  // Remove item
  const removeFromCart = async (dishName) => {
    try {
      const token = localStorage.getItem("token");
      const res = await axios.post(
        "http://localhost:5000/api/cart/remove",
        { dishName },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setCart(res.data.cart.items || []);
    } catch (err) {
      console.error("Failed to remove item:", err);
    }
  };

  // Calculate total
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <div className="bg-amber-50 min-h-screen flex flex-col text-gray-800">
      <header className="bg-amber-900 px-6 py-4 flex items-center justify-between text-white">
        <div className="flex items-center gap-3">
          <img src="/logo.png" alt="MealMingle Logo" className="h-12 w-12 rounded-full" />
          <h1 className="text-2xl font-bold">MEALMINGLE</h1>
        </div>
        <Link
          to="/"
          className="bg-red-600 text-white px-4 py-2 rounded-full hover:bg-red-700 transition flex items-center gap-2"
        >
          <i className="fas fa-home"></i>
          <span>Home</span>
        </Link>
      </header>

      <section className="max-w-5xl mx-auto py-10 px-6 flex-1">
        <h2 className="text-3xl font-bold text-amber-900 mb-6">🛒 Your Cart</h2>

        {cart.length === 0 ? (
          <p className="text-gray-600 text-lg text-center">
            Your cart is empty. Go back and add something delicious!
          </p>
        ) : (
          <div className="space-y-6">
            {cart.map((item, index) => (
              <div
                key={index}
                className="flex flex-col sm:flex-row items-center bg-white shadow-md rounded-lg p-4 gap-4"
              >
                <img src={item.img} alt={item.dishName} className="w-32 h-32 object-cover rounded-lg" />
                <div className="flex-1 text-center sm:text-left">
                  <h3 className="text-xl font-semibold text-amber-800">{item.dishName}</h3>
                  <p className="text-gray-700 text-lg">
                    Rs. {item.price} x {item.quantity}
                  </p>
                </div>
                <button
                  onClick={() => removeFromCart(item.dishName)}
                  className="bg-red-600 text-white px-4 py-2 rounded-full hover:bg-red-700 transition"
                >
                  Remove
                </button>
              </div>
            ))}

            <div className="text-right mt-6">
              <h3 className="text-2xl font-bold text-red-700">Total: Rs. {total}</h3>
            </div>

            <div className="text-center mt-8">
              <Link
                to="/checkout"
                className="bg-amber-900 text-white px-6 py-3 rounded-full text-lg font-semibold hover:bg-amber-950 transition"
              >
                Proceed to Checkout
              </Link>
            </div>
          </div>
        )}
      </section>

      <footer className="bg-amber-950 text-white py-6 text-center mt-10">
        <p className="text-sm">© 2025 MealMingle. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default CartPage;
