import express from "express";
import adminAuth from "../middleware/adminAuth.js";
import User from "../models/User.js";
import Product from "../models/Product.js";
import Restaurant from "../models/Restaurant.js"; // import Restaurant model

const router = express.Router();

// ✅ Get all users (Admin only)
router.get("/users", adminAuth, async (req, res) => {
  try {
    const users = await User.find().select("-password"); // exclude passwords
    res.json(users);
  } catch (err) {
    console.error("Error fetching users:", err);
    res.status(500).json({ success: false, message: "Server error while fetching users" });
  }
});

// ✅ Get all menus (Admin only)
// Get all restaurants with their menus (Admin only)
router.get("/restaurants", adminAuth, async (req, res) => {
  try {
    const restaurants = await Restaurant.find();

    // Fetch all products (menus) and group by restaurant
    const products = await Product.find();

    const restaurantsWithMenus = restaurants.map(r => ({
      ...r._doc, // include all restaurant fields
      menu: products.filter(p => p.restaurant.toString() === r._id.toString())
    }));

    res.json(restaurantsWithMenus);
  } catch (err) {
    console.error("Error fetching restaurants with menus:", err);
    res.status(500).json({ success: false, message: "Server error while fetching restaurants" });
  }
});



export default router;
