import express from "express";

const router = express.Router();

router.post("/", (req, res) => {
  const message = (req.body.message || "").toLowerCase();

  let reply =
    "Hi 👋 I’m MealMingle Assistant. You can ask about menus, booking, or orders.";

  if (message.includes("menu")) {
    reply =
      "You can browse restaurant menus from the home page. Select a restaurant to view its menu.";
  } else if (message.includes("book")) {
    reply =
      "To book a table, go to the Book Table page and fill in your details.";
  } else if (message.includes("time") || message.includes("open")) {
    reply =
      "Most restaurants are open from 12 PM to 11 PM. Timings may vary by restaurant.";
  } else if (message.includes("order")) {
    reply =
      "You can place orders by adding items to your cart and checking out.";
  } else if (message.includes("delivery")) {
    reply =
      "Delivery availability depends on the restaurant you choose.";
  } else if (message.includes("contact")) {
    reply =
      "You can contact MealMingle via email at support@mealmingle.com.";
  } else if (message.includes("admin")) {
    reply =
      "Admin access is restricted. Please log in through the admin panel.";
  }

  res.json({ reply });
});

export default router;
