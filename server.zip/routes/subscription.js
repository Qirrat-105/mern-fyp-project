import express from "express";
import Product from "../models/Product.js";
import Subscription from "../models/Subscription.js";
import auth from "../middleware/auth.js";
import adminAuth from "../middleware/adminAuth.js";

const router = express.Router();

/* =================================================
   USER ROUTES
================================================= */

// ✅ USER: Generate weekly plan WITH preferences
router.post("/generate", auth, async (req, res) => {
  try {
    const { budget, calories, diet, cuisines } = req.body;

    // 🔒 Block if user already has pending subscription
    const existingPending = await Subscription.findOne({
      user: req.user.id,
      status: "pending",
    });

    if (existingPending) {
      return res.status(400).json({
        success: false,
        message: "You already have a pending subscription awaiting approval",
      });
    }

    // Fetch menu items
    const products = await Product.find().select("dishName");

    if (!products.length) {
      return res.status(404).json({
        success: false,
        message: "No menu items available",
      });
    }

    // Shuffle meals
    const mealPool = products
      .map((p) => p.dishName)
      .sort(() => 0.5 - Math.random());

    // Build weekly plan
    const weeklyPlan = [];
    let index = 0;

    for (let day = 1; day <= 7; day++) {
      weeklyPlan.push({
        day,
        meals: [
          mealPool[index % mealPool.length],
          mealPool[(index + 1) % mealPool.length],
        ],
      });
      index += 2;
    }

    // Save subscription
    const subscription = await Subscription.create({
      user: req.user.id,
      weekStart: new Date(),
      meals: weeklyPlan,
      status: "pending",
      preferences: {
        budget,
        calories,
        diet,
        cuisines,
      },
    });

    res.json({
      success: true,
      message: "Weekly plan generated. Waiting for admin approval.",
      plan: subscription,
    });
  } catch (error) {
    console.error("Subscription generate error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
});

// ✅ USER: Get latest subscription (ANY status)
router.get("/my-latest", auth, async (req, res) => {
  try {
    const plan = await Subscription.findOne({ user: req.user.id })
      .sort({ createdAt: -1 });

    if (!plan) {
      return res.json({
        success: false,
        message: "No subscription found",
      });
    }

    res.json({
      success: true,
      plan,
    });
  } catch (error) {
    console.error("Fetch latest subscription error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
});

/* =================================================
   ADMIN ROUTES
================================================= */

// ✅ ADMIN: Get all pending subscriptions
router.get("/admin/pending", auth, adminAuth, async (req, res) => {
  try {
    const plans = await Subscription.find({ status: "pending" })
      .populate("user", "name email");

    res.json({ success: true, plans });
  } catch (error) {
    console.error("Admin fetch error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
});

// ✅ ADMIN: Approve subscription
router.put("/admin/approve/:id", auth, adminAuth, async (req, res) => {
  try {
    const plan = await Subscription.findById(req.params.id);

    if (!plan) {
      return res.status(404).json({
        success: false,
        message: "Subscription not found",
      });
    }

    plan.status = "approved";
    await plan.save();

    // 🔔 REAL-TIME NOTIFICATION
    const io = req.app.get("io");
    io.to(plan.user.toString()).emit("subscriptionNotification", {
      message: "✅ Your weekly meal subscription has been approved!",
      status: "approved",
    });

    res.json({
      success: true,
      message: "Subscription approved successfully",
    });
  } catch (error) {
    console.error("Approve error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
});

// ❌ ADMIN: Cancel subscription
router.put("/admin/cancel/:id", auth, adminAuth, async (req, res) => {
  try {
    const plan = await Subscription.findById(req.params.id);

    if (!plan) {
      return res.status(404).json({
        success: false,
        message: "Subscription not found",
      });
    }

    plan.status = "cancelled";
    await plan.save();

    // 🔔 REAL-TIME NOTIFICATION
    const io = req.app.get("io");
    io.to(plan.user.toString()).emit("subscriptionNotification", {
      message: "❌ Your weekly meal subscription has been cancelled.",
      status: "cancelled",
    });

    res.json({
      success: true,
      message: "Subscription cancelled successfully",
    });
  } catch (error) {
    console.error("Cancel error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
});

export default router;
