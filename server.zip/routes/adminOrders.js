import express from "express";
import mongoose from "mongoose";
import Order from "../models/Order.js";
import verifyToken from "../middleware/auth.js";
import adminAuth from "../middleware/adminAuth.js";

const router = express.Router();

// ✅ 1. GET all orders (admin only)
router.get("/orders", verifyToken, adminAuth, async (req, res) => {
  try {
    const orders = await Order.find().populate("user", "-password");
    res.status(200).json({ success: true, orders });
  } catch (error) {
    console.error("Fetch orders error:", error);
    res.status(500).json({
      success: false,
      message: "Server error fetching orders",
    });
  }
});

// ✅ 2. GET single order by ID
router.get("/orders/:id", verifyToken, async (req, res) => {
  try {
    const { id } = req.params;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid order ID",
      });
    }

    const order = await Order.findById(id).populate("user", "-password");

    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Order not found",
      });
    }

    if (
      req.user.role !== "admin" &&
      req.user.id !== order.user._id.toString()
    ) {
      return res.status(403).json({
        success: false,
        message: "Access denied",
      });
    }

    res.status(200).json({ success: true, order });
  } catch (error) {
    console.error("Fetch order error:", error);
    res.status(500).json({
      success: false,
      message: "Server error fetching order",
    });
  }
});

// ✅ 3. UPDATE order status (ADMIN ONLY)
router.put(
  "/orders/:orderId/status",
  verifyToken,
  adminAuth,
  async (req, res) => {
    try {
      const { orderId } = req.params;
      const { status } = req.body;

      if (!mongoose.Types.ObjectId.isValid(orderId)) {
        return res.status(400).json({
          success: false,
          message: "Invalid order ID",
        });
      }

      const order = await Order.findById(orderId);

      if (!order) {
        return res.status(404).json({
          success: false,
          message: "Order not found",
        });
      }

      order.status = status;
      await order.save();

      // 🔔 SOCKET NOTIFICATION
     // 🔔 SOCKET NOTIFICATION
const io = req.app.get("io");

console.log("Emitting to user:", order.user.toString()); // 👈 ADD THIS

io.to(order.user.toString()).emit("orderStatusUpdated", {
  orderId: order._id,
  status: order.status,
});


      res.status(200).json({
        success: true,
        message: "Order status updated",
        order,
      });
    } catch (error) {
      console.error("Update order status error:", error);
      res.status(500).json({
        success: false,
        message: "Server error updating order status",
      });
    }
  }
);

export default router;
