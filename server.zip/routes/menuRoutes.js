import express from "express";
import Menu from "../models/Menu.js";

const router = express.Router();

// Get all menus
router.get("/", async (req, res) => {
  const menus = await Menu.find();
  res.json(menus);
});

// Add new menu item
router.post("/", async (req, res) => {
  const newMenu = new Menu(req.body);
  await newMenu.save();
  res.json({ message: "Menu item added successfully" });
});

// Delete menu
router.delete("/:id", async (req, res) => {
  await Menu.findByIdAndDelete(req.params.id);
  res.json({ message: "Menu item deleted" });
});

export default router;
