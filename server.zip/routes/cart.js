import express from "express";
import Cart from "../models/Cart.js";
import Product from "../models/Product.js";
import Restaurant from "../models/Restaurant.js";
import auth from "../middleware/auth.js";

const router = express.Router();

// ✅ Get user's cart
router.get("/", auth, async (req, res) => {
  try {
    let cart = await Cart.findOne({ user: req.user.id })
      .populate('items.product')
      .populate('items.restaurant');
    
    if (!cart) {
      cart = new Cart({
        user: req.user.id,
        items: []
      });
      await cart.save();
    }

    res.json({
      success: true,
      cart: {
        items: cart.items.map(item => ({
          productId: item.product._id,
          dishName: item.product.dishName,
          price: item.product.price,
          quantity: item.quantity,
          img: item.product.image,
          restaurantId: item.restaurant._id,
          restaurantName: item.restaurant.name
        })),
        currentRestaurant: cart.items.length > 0 ? {
          id: cart.items[0].restaurant._id,
          name: cart.items[0].restaurant.name
        } : null
      }
    });
  } catch (error) {
    console.error("Get cart error:", error);
    res.status(500).json({ 
      success: false, 
      message: "Server error while fetching cart" 
    });
  }
});

// ✅ Add item to cart (with restaurant validation)
router.post("/add", auth, async (req, res) => {
  try {
    const { productId, quantity = 1 } = req.body;

    if (!productId) {
      return res.status(400).json({ 
        success: false, 
        message: "Product ID is required" 
      });
    }

    // Get product with restaurant info
    const product = await Product.findById(productId).populate('restaurant');
    if (!product) {
      return res.status(404).json({ 
        success: false, 
        message: "Product not found" 
      });
    }

    let cart = await Cart.findOne({ user: req.user.id });
    
    if (!cart) {
      cart = new Cart({
        user: req.user.id,
        items: []
      });
    }

    // Check if adding item from different restaurant
    if (cart.items.length > 0) {
      const currentRestaurantId = cart.items[0].restaurant.toString();
      const newRestaurantId = product.restaurant._id.toString();
      
      if (currentRestaurantId !== newRestaurantId) {
        return res.status(400).json({ 
          success: false, 
          message: `Your cart contains items from ${cart.items[0].restaurantName}. Please clear your cart or complete your order before ordering from ${product.restaurant.name}.` 
        });
      }
    }

    // Add/update item in cart
    const existingItemIndex = cart.items.findIndex(
      item => item.product.toString() === productId
    );

    if (existingItemIndex > -1) {
      cart.items[existingItemIndex].quantity += parseInt(quantity);
    } else {
      cart.items.push({ 
        product: productId, 
        quantity: parseInt(quantity),
        restaurant: product.restaurant._id,
        restaurantName: product.restaurant.name
      });
    }

    await cart.save();
    await cart.populate('items.product');
    await cart.populate('items.restaurant');

    res.json({
      success: true,
      message: "Item added to cart successfully",
      cart: {
        items: cart.items.map(item => ({
          productId: item.product._id,
          dishName: item.product.dishName,
          price: item.product.price,
          quantity: item.quantity,
          img: item.product.image,
          restaurantId: item.restaurant._id,
          restaurantName: item.restaurant.name
        })),
        currentRestaurant: cart.items.length > 0 ? {
          id: cart.items[0].restaurant._id,
          name: cart.items[0].restaurant.name
        } : null
      }
    });
  } catch (error) {
    console.error("Add to cart error:", error);
    res.status(500).json({ 
      success: false, 
      message: "Server error while adding item to cart" 
    });
  }
});

// ✅ Check if can add to cart from specific restaurant
router.get("/can-add/:restaurantId", auth, async (req, res) => {
  try {
    const { restaurantId } = req.params;
    const cart = await Cart.findOne({ user: req.user.id });

    if (!cart || cart.items.length === 0) {
      return res.json({
        success: true,
        canAdd: true,
        message: "Cart is empty"
      });
    }

    const currentRestaurantId = cart.items[0].restaurant.toString();
    
    if (currentRestaurantId !== restaurantId) {
      const currentRestaurant = await Restaurant.findById(currentRestaurantId);
      return res.json({
        success: true,
        canAdd: false,
        message: `Your cart contains items from ${currentRestaurant.name}. Please clear your cart first.`,
        currentRestaurant: currentRestaurant.name
      });
    }

    res.json({
      success: true,
      canAdd: true,
      message: "Can add items from this restaurant"
    });
  } catch (error) {
    console.error("Check can add error:", error);
    res.status(500).json({ 
      success: false, 
      message: "Server error" 
    });
  }
});
// ✅ Update item quantity in cart
router.post("/update", auth, async (req, res) => {
  try {
    const { productId, quantity } = req.body;

    if (!productId || quantity == null) {
      return res.status(400).json({
        success: false,
        message: "Product ID and quantity are required"
      });
    }

    let cart = await Cart.findOne({ user: req.user.id });
    if (!cart) {
      return res.status(404).json({
        success: false,
        message: "Cart not found"
      });
    }

    const itemIndex = cart.items.findIndex(item => item.product.toString() === productId);
    if (itemIndex === -1) {
      return res.status(404).json({
        success: false,
        message: "Product not in cart"
      });
    }

    cart.items[itemIndex].quantity = parseInt(quantity);

    // Remove item if quantity becomes 0
    if (cart.items[itemIndex].quantity <= 0) {
      cart.items.splice(itemIndex, 1);
    }

    await cart.save();
    await cart.populate('items.product');
    await cart.populate('items.restaurant');

    res.json({
      success: true,
      message: "Cart updated successfully",
      cart: {
        items: cart.items.map(item => ({
          productId: item.product._id,
          dishName: item.product.dishName,
          price: item.product.price,
          quantity: item.quantity,
          img: item.product.image,
          restaurantId: item.restaurant._id,
          restaurantName: item.restaurant.name
        })),
        currentRestaurant: cart.items.length > 0 ? {
          id: cart.items[0].restaurant._id,
          name: cart.items[0].restaurant.name
        } : null
      }
    });
  } catch (error) {
    console.error("Update cart error:", error);
    res.status(500).json({
      success: false,
      message: "Server error while updating cart"
    });
  }
});
// ✅ Remove single item from cart
router.post("/remove", auth, async (req, res) => {
  try {
    const { productId } = req.body;

    if (!productId) {
      return res.status(400).json({
        success: false,
        message: "Product ID is required"
      });
    }

    const cart = await Cart.findOne({ user: req.user.id });

    if (!cart) {
      return res.status(404).json({
        success: false,
        message: "Cart not found"
      });
    }

    cart.items = cart.items.filter(
      item => item.product.toString() !== productId
    );

    await cart.save();
    await cart.populate("items.product");
    await cart.populate("items.restaurant");

    res.json({
      success: true,
      message: "Item removed from cart",
      cart: {
        items: cart.items.map(item => ({
          productId: item.product._id,
          dishName: item.product.dishName,
          price: item.product.price,
          quantity: item.quantity,
          img: item.product.image,
          restaurantId: item.restaurant._id,
          restaurantName: item.restaurant.name
        })),
        currentRestaurant: cart.items.length > 0
          ? {
              id: cart.items[0].restaurant._id,
              name: cart.items[0].restaurant.name
            }
          : null
      }
    });
  } catch (error) {
    console.error("Remove cart item error:", error);
    res.status(500).json({
      success: false,
      message: "Server error while removing item"
    });
  }
});
// ✅ Clear entire cart
router.post("/clear", auth, async (req, res) => {
  try {
    const cart = await Cart.findOne({ user: req.user.id });

    if (!cart) {
      return res.status(404).json({
        success: false,
        message: "Cart not found"
      });
    }

    cart.items = [];
    await cart.save();

    res.json({
      success: true,
      message: "Cart cleared successfully",
      cart: {
        items: [],
        currentRestaurant: null
      }
    });
  } catch (error) {
    console.error("Clear cart error:", error);
    res.status(500).json({
      success: false,
      message: "Server error while clearing cart"
    });
  }
});


export default router;