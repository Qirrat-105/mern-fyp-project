import express from "express";
import Booking from "../models/Booking.js";

const router = express.Router();

/* GET ALL BOOKINGS – ADMIN */
router.get("/bookings", async (req, res) => {
  try {
    const bookings = await Booking.find().sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      bookings,
    });
  } catch (error) {
    console.error("Admin booking fetch error:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch bookings",
    });
  }
});

export default router;
