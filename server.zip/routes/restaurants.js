import express from "express";
import Restaurant from "../models/Restaurant.js";
import Product from "../models/Product.js";

const router = express.Router();

// ✅ Get all restaurants
router.get("/", async (req, res) => {
  try {
    const restaurants = await Restaurant.find({ available: true });
    res.json({ 
      success: true, 
      restaurants 
    });
  } catch (error) {
    console.error("Get restaurants error:", error);
    res.status(500).json({ 
      success: false, 
      message: "Server error while fetching restaurants" 
    });
  }
});

// ✅ Get restaurant by name
router.get("/name/:name", async (req, res) => {
  try {
    const restaurantName = req.params.name.replace(/%20/g, ' '); // Decode URL spaces
    console.log("🔍 Looking for restaurant:", restaurantName);
    
    const restaurant = await Restaurant.findOne({ 
      name: { $regex: new RegExp(restaurantName, 'i') } 
    });
    
    if (!restaurant) {
      return res.status(404).json({ 
        success: false, 
        message: "Restaurant not found" 
      });
    }

    res.json({
      success: true,
      restaurant
    });
  } catch (error) {
    console.error("Get restaurant by name error:", error);
    res.status(500).json({ 
      success: false, 
      message: "Server error while fetching restaurant" 
    });
  }
});

// ✅ Get restaurant menu by ID
router.get("/:id/menu", async (req, res) => {
  try {
    const restaurantId = req.params.id;
    console.log("🔍 Fetching menu for restaurant ID:", restaurantId);
    
    const menu = await Product.find({ 
      restaurant: restaurantId, 
      available: true 
    });

    const restaurant = await Restaurant.findById(restaurantId);

    if (!restaurant) {
      return res.status(404).json({ 
        success: false, 
        message: "Restaurant not found" 
      });
    }

    res.json({
      success: true,
      restaurant: {
        id: restaurant._id,
        name: restaurant.name,
        image: restaurant.image
      },
      menu
    });
  } catch (error) {
    console.error("Get menu error:", error);
    res.status(500).json({ 
      success: false, 
      message: "Server error while fetching menu" 
    });
  }
});

// ✅ Get restaurant by ID
router.get("/:id", async (req, res) => {
  try {
    const restaurant = await Restaurant.findById(req.params.id);
    if (!restaurant) {
      return res.status(404).json({ 
        success: false, 
        message: "Restaurant not found" 
      });
    }

    res.json({
      success: true,
      restaurant
    });
  } catch (error) {
    console.error("Get restaurant error:", error);
    res.status(500).json({ 
      success: false, 
      message: "Server error while fetching restaurant" 
    });
  }
});

export default router;