import express from "express";
import mongoose from "mongoose";
import Booking from "../models/Booking.js";


const router = express.Router();
router.use(express.json());

/* ------------------- Booking Schema ------------------- */
const bookingSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true },
  phone: { type: String, required: true },
  date: { type: String, required: true },
  time: { type: String, required: true },
  guests: { type: Number, required: true },
  restaurant: { type: String, required: true },
  message: { type: String },
  createdAt: { type: Date, default: Date.now },
});


/* ------------------- Validation Helpers ------------------- */
const nameRegex = /^[A-Za-z\s]{3,50}$/;
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const phoneRegex = /^\+?\d{10,15}$/;

/* ------------------- Book Table ------------------- */
router.post("/", async (req, res) => {
  const { name, email, phone, date, time, guests, restaurant, message } = req.body;

  /* ---------- Required fields ---------- */
  if (!name || !email || !phone || !date || !time || !guests || !restaurant) {
    return res.status(400).json({
      success: false,
      message: "All fields are required",
    });
  }

  /* ---------- Name validation ---------- */
  if (!nameRegex.test(name.trim())) {
    return res.status(400).json({
      success: false,
      message: "Name must contain only letters and be at least 3 characters long",
    });
  }

  /* ---------- Email validation ---------- */
  if (!emailRegex.test(email.trim())) {
    return res.status(400).json({
      success: false,
      message: "Please enter a valid email address",
    });
  }

  /* ---------- Phone validation ---------- */
  if (!phoneRegex.test(phone.trim())) {
    return res.status(400).json({
      success: false,
      message: "Phone number must contain 10 to 15 digits",
    });
  }

  /* ---------- Guests validation ---------- */
  if (!Number.isInteger(Number(guests)) || guests < 1 || guests > 20) {
    return res.status(400).json({
      success: false,
      message: "Guests must be a number between 1 and 20",
    });
  }

  try {
    const booking = new Booking({
      name: name.trim(),
      email: email.trim(),
      phone: phone.trim(),
      date,
      time,
      guests,
      restaurant,
      message: message?.trim(),
    });

    await booking.save();

    res.status(201).json({
      success: true,
      message: "Booking successful!",
    });
  } catch (err) {
    console.error("Booking error:", err);
    res.status(500).json({
      success: false,
      message: "Server error. Please try again later.",
    });
  }
});

export default router;
