import mongoose from "mongoose";
import Product from "./models/Product.js";
import Restaurant from "./models/Restaurant.js";
import dotenv from "dotenv";

dotenv.config();

const allRestaurants = [
  {
    name: "Spice Lounge",
    description: "Desi & Indian cuisine with bold spices.",
    image: "logo1.jpeg",
    rating: 4.2,
    cuisine: "Indian",
    deliveryTime: "30-40 min",
    menuRoute: "/spiceloungemenu"
  },
  {
    name: "Urban Bites",
    description: "Trendy fast food with a desi twist.",
    image: "logo2.jpg",
    rating: 5.0,
    cuisine: "Fast Food",
    deliveryTime: "25-35 min",
    menuRoute: "/urban-bites-menu"
  },
  {
    name: "The Hungry Fork",
    description: "Comfort food & cozy ambiance.",
    image: "logo3.jpeg",
    rating: 4.5,
    cuisine: "Continental",
    deliveryTime: "35-45 min",
    menuRoute: "/hungryfork-menu"
  },
  {
    name: "Pizza Online",
    description: "Freshly baked pizzas delivered in minutes.",
    image: "logo21.png",
    rating: 4.4,
    cuisine: "Italian",
    deliveryTime: "20-30 min",
    menuRoute: "/pizzaonline-menu"
  },
  {
    name: "Host Café",
    description: "Chai, coffee, and snacks with comfort vibes.",
    image: "logo22.jpeg",
    rating: 4.8,
    cuisine: "Cafe",
    deliveryTime: "15-25 min",
    menuRoute: "/hostcafe-menu"
  },
  {
    name: "BBQ Bazaar",
    description: "Barbecue & grilled meat paradise.",
    image: "logo4.jpeg",
    rating: 4.3,
    cuisine: "BBQ",
    deliveryTime: "40-50 min",
    menuRoute: "/bbqbazaar-menu"
  },
  {
    name: "Karachi Kitchen",
    description: "Authentic biryani & seafood dishes.",
    image: "logo5.png",
    rating: 5.0,
    cuisine: "Pakistani",
    deliveryTime: "35-45 min",
    menuRoute: "/karachikitchen-menu"
  },
  {
    name: "Lahori Chargha House",
    description: "Flaming chargha with true Lahori taste.",
    image: "logo6.jpeg",
    rating: 4.0,
    cuisine: "Pakistani",
    deliveryTime: "40-50 min",
    menuRoute: "/lahoricharghahouse-menu"
  },
  {
    name: "Bun Kebabi",
    description: "Iconic street food of Karachi.",
    image: "logo7.png",
    rating: 5.0,
    cuisine: "Street Food",
    deliveryTime: "20-30 min",
    menuRoute: "/bunkebabi-menu"
  },
  {
    name: "Zaiqa Junction",
    description: "Flavors from every corner of Pakistan.",
    image: "logo8.jpg",
    rating: 4.6,
    cuisine: "Pakistani",
    deliveryTime: "30-40 min",
    menuRoute: "/zaiqajunction-menu"
  },
  {
    name: "Royal Nihari",
    description: "Delicious breakfast & desi items.",
    image: "logo9.jpeg",
    rating: 4.9,
    cuisine: "Pakistani",
    deliveryTime: "25-35 min",
    menuRoute: "/royalnihari-menu"
  },
  {
    name: "Taste Yard",
    description: "Fusion meals & fast food treats.",
    image: "logo10.jpeg",
    rating: 4.4,
    cuisine: "Fusion",
    deliveryTime: "30-40 min",
    menuRoute: "/tasteyard-menu"
  }
];

// Menu items for each restaurant type
const getMenuItemsByCuisine = (restaurantId, restaurantName, cuisine) => {
  const commonItems = [
    {
      dishName: "Chicken Biryani",
      price: 450,
      description: "Aromatic basmati rice with tender chicken pieces",
      image: "biryani.jpg",
      category: "Main Course",
      restaurant: restaurantId,
      restaurantName: restaurantName
    },
    {
      dishName: "Garlic Naan",
      price: 80,
      description: "Soft bread topped with garlic and butter",
      image: "naan.jpg",
      category: "Bread",
      restaurant: restaurantId,
      restaurantName: restaurantName
    },
    {
      dishName: "Mango Lassi",
      price: 150,
      description: "Refreshing yogurt drink with sweet mango pulp",
      image: "lassi.jpg",
      category: "Beverage",
      restaurant: restaurantId,
      restaurantName: restaurantName
    }
  ];

  // Cuisine-specific items
  const specificItems = [];
  
  if (cuisine === "Indian") {
    specificItems.push(
      {
        dishName: "Butter Chicken",
        price: 750,
        description: "Creamy tomato-based curry with tender chicken",
        image: "butter-chicken.jpg",
        category: "Main Course",
        restaurant: restaurantId,
        restaurantName: restaurantName
      },
      {
        dishName: "Palak Paneer",
        price: 650,
        description: "Fresh spinach curry with soft cottage cheese",
        image: "palak-paneer.jpg",
        category: "Main Course",
        restaurant: restaurantId,
        restaurantName: restaurantName
      }
    );
  } else if (cuisine === "Fast Food") {
    specificItems.push(
      {
        dishName: "Zinger Burger",
        price: 450,
        description: "Crispy chicken burger with special sauce",
        image: "burger.jpg",
        category: "Fast Food",
        restaurant: restaurantId,
        restaurantName: restaurantName
      },
      {
        dishName: "French Fries",
        price: 200,
        description: "Golden crispy fries with ketchup",
        image: "fries.jpg",
        category: "Fast Food",
        restaurant: restaurantId,
        restaurantName: restaurantName
      }
    );
  } else if (cuisine === "Italian") {
    specificItems.push(
      {
        dishName: "Margherita Pizza",
        price: 800,
        description: "Classic pizza with tomato sauce and mozzarella",
        image: "pizza.jpg",
        category: "Pizza",
        restaurant: restaurantId,
        restaurantName: restaurantName
      },
      {
        dishName: "Pasta Alfredo",
        price: 650,
        description: "Creamy pasta with parmesan cheese",
        image: "pasta.jpg",
        category: "Pasta",
        restaurant: restaurantId,
        restaurantName: restaurantName
      }
    );
  } else if (cuisine === "BBQ") {
    specificItems.push(
      {
        dishName: "Chicken Tikka",
        price: 520,
        description: "Boneless chicken pieces marinated and grilled",
        image: "chicken-tikka.jpg",
        category: "BBQ",
        restaurant: restaurantId,
        restaurantName: restaurantName
      },
      {
        dishName: "Beef Boti",
        price: 680,
        description: "Succulent beef chunks grilled on skewers",
        image: "beef-boti.jpg",
        category: "BBQ",
        restaurant: restaurantId,
        restaurantName: restaurantName
      }
    );
  } else if (cuisine === "Pakistani") {
    specificItems.push(
      {
        dishName: "Chicken Karahi",
        price: 850,
        description: "Traditional Pakistani chicken curry",
        image: "karahi.jpg",
        category: "Main Course",
        restaurant: restaurantId,
        restaurantName: restaurantName
      },
      {
        dishName: "Beef Nihari",
        price: 600,
        description: "Slow-cooked beef in aromatic spices",
        image: "nihari.jpg",
        category: "Main Course",
        restaurant: restaurantId,
        restaurantName: restaurantName
      }
    );
  } else if (cuisine === "Street Food") {
    specificItems.push(
      {
        dishName: "Bun Kebab",
        price: 120,
        description: "Spiced patty in soft bun with chutney",
        image: "bun-kebab.jpg",
        category: "Street Food",
        restaurant: restaurantId,
        restaurantName: restaurantName
      },
      {
        dishName: "Chaat Papri",
        price: 180,
        description: "Crispy wafers with yogurt and tamarind sauce",
        image: "chaat.jpg",
        category: "Street Food",
        restaurant: restaurantId,
        restaurantName: restaurantName
      }
    );
  } else if (cuisine === "Cafe") {
    specificItems.push(
      {
        dishName: "Cappuccino",
        price: 350,
        description: "Freshly brewed coffee with steamed milk",
        image: "cappuccino.jpg",
        category: "Beverage",
        restaurant: restaurantId,
        restaurantName: restaurantName
      },
      {
        dishName: "Chocolate Cake",
        price: 450,
        description: "Rich chocolate cake slice",
        image: "cake.jpg",
        category: "Dessert",
        restaurant: restaurantId,
        restaurantName: restaurantName
      }
    );
  }

  return [...commonItems, ...specificItems];
};

const seedAllRestaurants = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log("✅ Connected to MongoDB");

    // Clear existing data
    console.log("🗑️ Clearing existing data...");
    await Restaurant.deleteMany({});
    await Product.deleteMany({});

    let totalRestaurants = 0;
    let totalProducts = 0;

    // Create all restaurants
    for (const restaurantData of allRestaurants) {
      console.log(`🏪 Creating ${restaurantData.name}...`);
      
      const restaurant = new Restaurant(restaurantData);
      await restaurant.save();
      totalRestaurants++;

      // Create menu items
      const menuItems = getMenuItemsByCuisine(
        restaurant._id, 
        restaurant.name, 
        restaurant.cuisine
      );
      
      await Product.insertMany(menuItems);
      totalProducts += menuItems.length;
      
      console.log(`✅ ${restaurant.name} - ${menuItems.length} menu items`);
    }

    console.log("\n🎉 Seeding completed!");
    console.log("📊 Summary:");
    console.log(`   - Restaurants: ${totalRestaurants}`);
    console.log(`   - Menu Items: ${totalProducts}`);
    
    // Show all restaurant IDs
    const restaurants = await Restaurant.find();
    console.log("\n🔍 Restaurant IDs:");
    restaurants.forEach(r => {
      console.log(`   ${r.name}: ${r._id}`);
    });

    process.exit(0);
  } catch (error) {
    console.error("❌ Seeding error:", error);
    process.exit(1);
  }
};

seedAllRestaurants();