import mongoose from "mongoose";
import Restaurant from "./models/Restaurant.js";
import Product from "./models/Product.js";
import dotenv from "dotenv";

dotenv.config();

const restaurantsData = [
  {
    name: "Spice Lounge",
    description: "Desi & Indian cuisine with bold spices.",
    image: "logo1.jpeg",
    rating: 4.2,
    cuisine: "Indian",
    menuRoute: "/spiceloungemenu"
  },
  {
    name: "Urban Bites",
    description: "Trendy fast food with a desi twist.",
    image: "logo2.jpg", 
    rating: 5.0,
    cuisine: "Fast Food",
    menuRoute: "/urban-bites-menu"
  },
  // Add all 12 restaurants here...
];

const seedData = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log("Connected to MongoDB");

    // Clear existing data
    await Restaurant.deleteMany({});
    await Product.deleteMany({});

    // Insert restaurants
    const restaurants = await Restaurant.insertMany(restaurantsData);
    console.log("Restaurants seeded successfully");

    // Create sample menu items for each restaurant
    for (const restaurant of restaurants) {
      const menuItems = [
        {
          dishName: "Chicken Biryani",
          price: 450,
          description: "Aromatic basmati rice with tender chicken pieces",
          image: "biryani.jpg",
          category: "Main Course",
          restaurant: restaurant._id,
          restaurantName: restaurant.name
        },
        {
          dishName: "Butter Chicken", 
          price: 550,
          description: "Creamy tomato-based curry with butter chicken",
          image: "butter-chicken.jpg",
          category: "Main Course",
          restaurant: restaurant._id,
          restaurantName: restaurant.name
        },
        // Add more menu items...
      ];

      await Product.insertMany(menuItems);
      console.log(`Menu items added for ${restaurant.name}`);
    }

    console.log("Data seeding completed!");
    process.exit(0);
  } catch (error) {
    console.error("Seeding error:", error);
    process.exit(1);
  }
};

seedData();