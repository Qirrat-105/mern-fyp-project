import mongoose from "mongoose";

const orderSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  items: [
    {
      product: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Product",
      },
      name: String, // 👈 Add this line
      quantity: Number,
      price: Number,
    },
  ],
  clientDetails: {
    name: String,
    email: String,
    phone: String,
    address: String,
  },
  total: {
    type: Number,
    required: true,
  },
  paymentMethod: {
    type: String,
    default: "Cash on Delivery",
  },
  status: {
    type: String,
    default: "Pending",
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

const Order = mongoose.model("Order", orderSchema);
export default Order;
