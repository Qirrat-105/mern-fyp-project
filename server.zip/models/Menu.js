import mongoose from "mongoose";

const menuSchema = new mongoose.Schema({
  restaurantName: String,
  dishName: String,
  price: Number,
  image: String,
});

export default mongoose.model("Menu", menuSchema);
