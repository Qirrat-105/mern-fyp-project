import mongoose from "mongoose";

const subscriptionSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    weekStart: {
      type: Date,
      required: true,
    },

    // ✅ Weekly meal plan
    meals: [
      {
        day: {
          type: Number,
          required: true,
        },
        meals: {
          type: [String],
          required: true,
        },
      },
    ],

    // ✅ User preferences (IMPORTANT)
    preferences: {
      budget: {
        type: Number,
        required: false,
      },
      calories: {
        type: Number,
        required: false,
      },
      diet: {
        type: String,
        required: false,
      },
      cuisines: {
        type: String,
        required: false,
      },
    },

    // ✅ Subscription status (admin controlled)
    status: {
      type: String,
      enum: ["pending", "approved", "cancelled"],
      default: "pending",
    },
  },
  { timestamps: true }
);

export default mongoose.model("Subscription", subscriptionSchema);
