import mongoose from "mongoose";

const restaurantSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    required: true
  },
  image: {
    type: String,
    required: true
  },
  rating: {
    type: Number,
    default: 0
  },
  cuisine: {
    type: String,
    required: true
  },
  deliveryTime: {
    type: String,
    default: "30-40 min"
  },
  available: {
    type: Boolean,
    default: true
  },
  menuRoute: {
  type: String,
  default: "/menu" // Make it optional with default value
},
  createdAt: {
    type: Date,
    default: Date.now
  }
});

export default mongoose.model("Restaurant", restaurantSchema);