import mongoose from "mongoose";

const confirmSchema = new mongoose.Schema({
  userId: {
    type: String,
    required: true,
  },
  orderItems: [
    {
      name: String,
      quantity: Number,
      price: Number,
    },
  ],
  totalAmount: {
    type: Number,
    required: true,
  },
  address: {
    type: String,
    required: true,
  },
  paymentMethod: {
    type: String,
    required: true,
  },
  status: {
    type: String,
    default: "Pending",
  },
}, { timestamps: true });

const Confirm = mongoose.model("Confirm", confirmSchema);

export default Confirm;
