import mongoose from "mongoose";
import Product from "./models/Product.js";
import Restaurant from "./models/Restaurant.js";
import dotenv from "dotenv";

dotenv.config();

const quickSeed = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log("✅ Connected to MongoDB");

    // Create Spice Lounge restaurant
    let restaurant = await Restaurant.findOne({ name: "Spice Lounge" });
    if (!restaurant) {
      restaurant = new Restaurant({
        name: "Spice Lounge",
        description: "Desi & Indian cuisine with bold spices.",
        image: "logo1.jpeg",
        rating: 4.2,
        cuisine: "Indian",
        deliveryTime: "30-40 min"
      });
      await restaurant.save();
      console.log("✅ Created Spice Lounge restaurant");
    }

    // Create products
    const products = [
      {
        dishName: "Chicken Biryani",
        price: 450,
        description: "Spicy rice with marinated chicken.",
        image: "/biryani.jpg",
        category: "Main Course",
        restaurant: restaurant._id,
        restaurantName: "Spice Lounge"
      },
      {
        dishName: "Mutton Karahi", 
        price: 3000,
        description: "Rich tomato gravy with tender mutton.",
        image: "/karahi.jpg",
        category: "Main Course",
        restaurant: restaurant._id,
        restaurantName: "Spice Lounge"
      },
      {
        dishName: "Garlic Naan",
        price: 80,
        description: "Freshly baked with butter and garlic.",
        image: "/naan.jpg", 
        category: "Bread",
        restaurant: restaurant._id,
        restaurantName: "Spice Lounge"
      }
    ];

    await Product.insertMany(products);
    console.log(`✅ Created ${products.length} products for Spice Lounge`);
    
    // Show the created product IDs
    const createdProducts = await Product.find({ restaurant: restaurant._id });
    console.log("📝 Created product IDs:");
    createdProducts.forEach(p => {
      console.log(`   ${p.dishName}: ${p._id}`);
    });

    process.exit(0);
  } catch (error) {
    console.error("❌ Seeding error:", error);
    process.exit(1);
  }
};

quickSeed();